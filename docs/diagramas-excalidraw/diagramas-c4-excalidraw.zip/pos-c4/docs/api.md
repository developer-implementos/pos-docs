# API de sucursal y persistencia

**Implementación en revisión:** F01 conecta Angular con `branch-api` y PostgreSQL. El incremento operativo Chile incorpora identidad propia POS, administración de accesos, provisión y HTTPS. Desde el [ADR-25](decisions/single-operational-mode.md) la API tiene un solo modo de operación, también en el ambiente local y en la CI. La infraestructura técnica pertenece a `libs/shared/backend/runtime`, `persistence` y `testing`; los casos de uso conservan su contexto de negocio. La [guía F01](phase-1-laboratory.md) describe el recorrido y sus límites.

> **Alcance:** la API administra usuarios, roles, puestos y configuración persistentes. Apertura, catálogo, clientes, cestas, cotización y efectivo se verifican sobre una sucursal aprovisionada con datos sintéticos que entran por las puertas oficiales. No se habilitan cobros operativos sin precios verificados, emisión fiscal, tarjetas ni envío ERP. El código está integrado en `main`; la aceptación de F01 se registra por separado en el producto. Esta documentación y la CI no acreditan habilitación productiva.

`apps/branch-api` compone el backend modular de sucursal con NestJS 12, Fastify 5 y TypeScript. Publica contratos HTTP v1 desde las bibliotecas de cada contexto, valida solicitudes con Zod y ejecuta los casos de uso mediante puertos. PostgreSQL 18.6 y `pg` 8.23.1 conservan la operación y su resultado durable. El [ADR-19](decisions/postgresql-unit-of-work.md) fija transacciones, migraciones y privilegios.

Los clientes `pos-desktop`, `pos-mobile` y `pos-web` sólo admiten el estado inicial `unconfigured` y el perfil conectado `branch`, que usa la API; un perfil inválido detiene el arranque. `country-api` tiene persistencia y sonda de ámbito propias, todavía sin recepción comercial. Los workers no procesan jobs de negocio; `erp-worker` incorpora una CLI separada de consultas Mountain que aún no alimenta el espejo ni la UI.

## Corte parcial F02 integrado

`branch-api` añade los contextos persistentes `payments`, `fiscal` y `devices`. Conservan intenciones, intentos, evidencia y destino bajo sus propias transacciones; no declaran un efecto externo a partir de un timeout o de un acuse técnico. Las rutas de operador y de host usan audiencias autenticadas distintas: una sesión POS no sustituye la credencial de instalación del dispositivo.

El protocolo de dispositivos incorpora recepción durable, permiso de ejecución de un uso y resultados identificados. El host .NET lo consume por HTTPS saliente y conserva su parte en SQLite; no accede a SQL de sucursal. La [guía F02](phase-2-payments-documents.md) detalla el recorrido, los estados y la interoperabilidad comprobada.

Los adaptadores de pagos y fiscalidad son exclusivos de pruebas, sin conexión a proveedores. La composición operativa no habilita un proveedor ni un numerador fiscal; el driver runtime de dispositivos declara capacidad no disponible. Estas APIs y sus pruebas no completan la UX de cobro, resolución, impresión o entrega de documentos prevista por el roadmap.

## Referencia Core

Las convenciones se contrastaron con [developer-implementos/core](https://github.com/developer-implementos/core/tree/b25164a50375845989a671cdc8e13360866c76af), commit `b25164a50375845989a671cdc8e13360866c76af`. La referencia es su código de arranque y sus contratos; no se incorpora Core como dependencia ni se conectan sus servicios.

| Referencia verificada en Core                                                                                                                                                                                                                                                                        | Aplicación en POS                                                                                                                  |
| ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ---------------------------------------------------------------------------------------------------------------------------------- |
| [Bootstrap y fábricas Nest/Fastify](https://github.com/developer-implementos/core/tree/b25164a50375845989a671cdc8e13360866c76af/apps/core-api/src/bootstrap)                                                                                                                                         | Separar creación, configuración HTTP/OpenAPI y listener en `shared/backend/runtime`; cada aplicación conserva su identidad y composición |
| [Módulo y servicio de configuración](https://github.com/developer-implementos/core/tree/b25164a50375845989a671cdc8e13360866c76af/apps/core-api/src/config)                                                                                                                                           | Validar una vez y publicar un snapshot inmutable mediante `RuntimeConfigModule` y `RuntimeConfigService`                           |
| [Logging con Pino](https://github.com/developer-implementos/core/tree/b25164a50375845989a671cdc8e13360866c76af/libs/shared/backend/observability/src/lib/logging)                                                                                                                                    | Unificar Nest y HTTP mediante `nestjs-pino`, conservar correlación y limitar los datos registrados                                 |
| [Filtro global de excepciones](https://github.com/developer-implementos/core/blob/b25164a50375845989a671cdc8e13360866c76af/apps/core-api/src/common/filters/global-exception.filter.ts)                                                                                                              | Respuesta plana con `code`, `message`, `category` y `timestamp`; la base POS omite `details` y oculta errores internos             |
| [Versionado URI del bootstrap](https://github.com/developer-implementos/core/blob/b25164a50375845989a671cdc8e13360866c76af/apps/core-api/src/bootstrap/bootstrap.ts) y [convenciones OpenAPI](https://github.com/developer-implementos/core/blob/b25164a50375845989a671cdc8e13360866c76af/AGENTS.md) | Prefijo `api`, versión URI `1`, sondas neutrales y documentación en español con `operationId` estables                             |
| [Helper Vitest/SWC](https://github.com/developer-implementos/core/blob/b25164a50375845989a671cdc8e13360866c76af/libs/shared/testing/src/config/vitest.helper.ts)                                                                                                                                     | Vitest con transformación SWC y metadata de decoradores para probar la inyección real de Nest                                      |

POS conserva pnpm, Nx 24 y NestJS 12. La incorporación de varias aplicaciones backend y librerías compartidas justifica Rspack/SWC con el plugin oficial de Nx para empaquetar fuentes internas, manteniendo TSC para comprobar tipos. Los artefactos incluyen manifiesto y lockfile de distribución; no necesitan resolver aliases desde el workspace. Se adapta el [empaquetado de Core](https://github.com/developer-implementos/core/blob/b25164a50375845989a671cdc8e13360866c76af/apps/core-api/rspack.config.js) sin copiar sus plugins correctivos ni su lista de dependencias cloud.

Para Sentry se toma como referencia la [inicialización y cierre de Core](https://github.com/developer-implementos/core/tree/b25164a50375845989a671cdc8e13360866c76af/apps/core-api/src/common/sentry), con una integración más acotada: un `NodeClient` privado de `@sentry/node` por aplicación, captura explícita y filtrado por campos permitidos. No se copia la inicialización global de `@sentry/nestjs`, el profiling ni las integraciones automáticas de Core. Pino sigue siendo el logger de Nest y HTTP; Sentry es un destino opcional para errores seleccionados.

La composición F01 no incorpora MongoDB, Redis, servicios cloud, OpenTelemetry ni la autenticación ecommerce de Core: no tiene esos consumidores ni contratos, y el backend de sucursal conserva el alcance de la propuesta POS. El [ADR-18](decisions/job-processing.md) selecciona BullMQ + Redis propio para trabajos de país y ERP, pendiente de implementación; no añade esa dependencia al backend de sucursal ni importa infraestructura de Core.

<span id="actualización-de-nombres-y-configuración"></span>

## Configuración

La aplicación HTTP de sucursal se llama `branch-api` y el worker de sincronización `branch-sync-worker`. La [convención de nombres](monorepo.md#nombres-de-las-aplicaciones-backend) distingue ámbito y tipo de proceso.

| Aplicación | Código fuente | Artefacto de distribución | Variables de entorno |
| --- | --- | --- | --- |
| `branch-api` | `apps/branch-api` | `dist/apps/branch-api` | `BRANCH_API_*` |
| `branch-sync-worker` | `apps/branch-sync-worker` | `dist/apps/branch-sync-worker` | `BRANCH_SYNC_WORKER_*` |

Los archivos `.env` de desarrollo y las variables del supervisor de procesos usan el prefijo de cada aplicación. Los ejemplos versionados documentan sus claves y valores predeterminados, sin secretos. La sección [Desarrollo](#desarrollo) detalla la carga y validación de esa configuración.

El campo `service` de `GET /api/v1`, logs y eventos Sentry de sucursal identifica `branch-api`; la salida de inspección, logs y eventos del worker identifican `branch-sync-worker`. Los comandos `api:*` operan sobre la API de sucursal y `sync:check` verifica la composición y cierre de su worker. `country-api` y `erp-worker` tienen configuración e identidad propias.

## Organización del runtime

La fábrica compone módulos y permite crear el servidor sin abrir un puerto para probarlo con Fastify. El arranque agrega escucha y cierre. `shared/backend/runtime` concentra configuración, HTTP/OpenAPI, logging, errores, sondas y ciclo de vida; `shared/backend/persistence` implementa conexiones y unidad de trabajo. Cada app conserva su identidad y manifiesto de migraciones.

Las librerías de `libs/backend` separan contratos, aplicación, dominio, infraestructura y adaptación HTTP donde existen esas responsabilidades. Las colaboraciones entre contextos usan contratos públicos; las apps componen sus adaptadores. La operación en efectivo coordina venta, caja y registro durable con la misma transacción. Los módulos de fases posteriores no devuelven éxitos comerciales ficticios.

## Desarrollo

Requiere Node.js `>=22.19.0 <23` o `>=24 <25` y pnpm 10.28.1, igual que el monorepo.

Desde la raíz:

```sh
pnpm install --frozen-lockfile
pnpm run api:dev
```

La API exige siempre HTTPS explícito, una base migrada y aprovisionada y una credencial runtime independiente de la de migración. `pnpm run local:api` la inicia con el ambiente local que prepara `local:provision`, igual que QA ([ambiente local](phase-1-laboratory.md#ambiente-local-y-comprobaciones)). Nx recompila cambios y reinicia la API; no aprovisiona una base automáticamente.

`pnpm run country:dev` inicia la base HTTP de país en `http://127.0.0.1:3001`. Las aplicaciones tienen identidades y composición separadas; iniciar ambas no establece una conexión entre ellas. Los [comandos del workspace](monorepo.md#comandos-del-workspace) también incluyen las verificaciones de los workers, que componen y cierran su contexto sin ejecutar trabajos de negocio.

Para configurar el entorno local, copia `apps/branch-api/.env.example` a `apps/branch-api/.env`. Nx carga ese archivo para sus tareas; las variables ya definidas en el entorno tienen prioridad. No versionar `.env` ni secretos. El arranque directo con Node no usa la carga de archivos de Nx: necesita variables del proceso o `node --env-file=/ruta/api.env main.js`.

La validación ocurre antes de escuchar conexiones. `RuntimeConfigModule` registra un snapshot inmutable y `RuntimeConfigService` lo expone a los módulos; los consumidores no necesitan consultar `process.env` ni reinterpretar valores.

| Variable               | Valor por defecto                                | Uso                                                                                            |
| ---------------------- | ------------------------------------------------ | ---------------------------------------------------------------------------------------------- |
| `NODE_ENV`             | `development`                                    | `development`, `test` o `production`                                                           |
| `BRANCH_API_HOST`         | `127.0.0.1`                                      | Dirección de escucha explícita, siempre con TLS configurado                                    |
| `BRANCH_API_PORT`         | `3000`                                           | Puerto TCP del servicio                                                                        |
| `BRANCH_API_LOG_LEVEL`    | `info`                                           | `trace`, `debug`, `info`, `warn`, `error`, `fatal` o `silent`                                  |
| `BRANCH_API_DOCS_ENABLED` | `true` en desarrollo/test; `false` en producción | Habilita el documento OpenAPI JSON                                                     |
| `BRANCH_API_CORS_ORIGINS` | vacío                                            | Orígenes HTTP/HTTPS exactos separados por comas; sin permisos entre orígenes por defecto       |

Para el cliente conectado, `BRANCH_API_CORS_ORIGINS` admite únicamente orígenes autorizados exactos, incluidos los de los canales nativos configurados. CORS no constituye autenticación ni autorización. Se requieren `BRANCH_API_BRANCH_ID` y `BRANCH_API_DATABASE_URL`. `BRANCH_API_PROFILE` está retirado: `operational` se acepta sin efecto mientras los servidores ya preparados lo conserven, y cualquier otro valor, como `laboratory`, detiene el arranque con un mensaje que nombra el ADR-25. La migración usa `BRANCH_API_MIGRATION_DATABASE_URL` con otra credencial. Las URLs y credenciales de instalaciones nunca se publican ni se registran en logs.

`BRANCH_API_DATABASE_TLS_MODE` usa `verify-full`; `disable-local` sólo se admite para una base en loopback, nunca para SQL remoto. HTTPS de la API utiliza `BRANCH_API_TLS_ENABLED`, `BRANCH_API_TLS_CERT_FILE` y `BRANCH_API_TLS_KEY_FILE`, con archivos externos protegidos. La sesión usa `BRANCH_API_SESSION_TTL_MS`. Los límites de búsqueda se configuran mediante `BRANCH_API_CATALOG_BURST` y `BRANCH_API_CATALOG_REFILL_PER_SECOND`. Los ejemplos del producto son la referencia de claves y defaults; la guía no conserva secretos ni replica la configuración de una instalación.

Estas variables corresponden a `branch-api`. `country-api` usa el prefijo `COUNTRY_API_` para las mismas opciones HTTP, con puerto predeterminado 3001. Los workers consumen `NODE_ENV`, su nivel de log (`BRANCH_SYNC_WORKER_LOG_LEVEL` o `ERP_WORKER_LOG_LEVEL`) y las opciones de reporte de errores descritas abajo; no configuran listener HTTP, CORS ni OpenAPI.

## Endpoints

| Método y ruta           | Responsabilidad                                        |
| ----------------------- | ------------------------------------------------------ |
| `GET /api/v1`           | Identifica el servicio y el alcance de esta base       |
| `GET /health/live`      | Comprueba que la aplicación responde                   |
| `GET /health/ready`     | Comprueba PostgreSQL, ámbito y migraciones/checksums compatibles |
| `GET /api/openapi.json` | Contrato OpenAPI, solo con `BRANCH_API_DOCS_ENABLED=true` |

```sh
curl --cacert <certificado-local> https://127.0.0.1:3333/api/v1
curl --cacert <certificado-local> https://127.0.0.1:3333/health/ready
```

El puerto 3333 es el predeterminado del ambiente local; `<certificado-local>` es el certificado de loopback que `local:provision` deja en `tmp/local/`.

Readiness de sucursal y país consulta su PostgreSQL correspondiente. Un esquema o ámbito incompatible impide declarar disponibilidad. La sonda no acredita ERP, dispositivos, pagos, permisos del operador o caja abierta; esas condiciones se validan en el caso de uso.

Las rutas llevan el prefijo `/api/v1`; los permisos de la sesión y las capacidades activadas en cada caja limitan su ejecución. El recorrido comercial completo siguiente está verificado sobre una sucursal aprovisionada con la publicación comercial ficticia; la presencia de una ruta no habilita su uso comercial operativo. Los contratos de cada contexto son la fuente de sus DTO; OpenAPI se genera desde esa misma definición.

| Rutas | Responsabilidad |
| --- | --- |
| `GET /auth/session`, `POST /auth/logout` | Consultar y revocar la sesión, limitada a actor, caja e instalación; se crea con el login con prueba de posesión de la tabla siguiente |
| `POST /auth/password` | Cambio de la contraseña propia |
| `GET /administration/access-options` | Consultar puestos autorizados y permisos otorgables |
| `GET/POST /administration/operators`, `PUT /administration/operators/:operatorId` | Consultar, crear y actualizar operadores propios del POS con permisos y versiones |
| `POST /administration/operators/:operatorId/password`, `/revoke-sessions` | Restablecer contraseña o revocar sesiones autorizadamente |
| `GET/POST /administration/roles`, `PUT /administration/roles/:roleId` | Administrar roles sin conceder privilegios superiores a los del administrador actuante |
| `GET /administration/operators/:operatorId/assignments`, `POST /administration/assignments`, `PUT /administration/assignments/:assignmentId` | Consultar y administrar asignaciones a puestos del ámbito |
| `GET /configuration/effective` | Recuperar configuración efectiva, procedencia, versión y capacidades |
| `GET /cash/shifts/current`, `POST /cash/shifts` | Consultar y abrir el turno autorizado |
| `GET /catalog/products`, `/catalog/product-codes/:code`, `/catalog/products/:productId/availability` | Buscar productos, resolver captura y consultar disponibilidad informativa |
| `GET /customers`, `/customers/:customerId` | Buscar y consultar clientes del maestro autorizado |
| `POST /customers/requests`, `GET /customers/requests/:requestId` | Solicitar alta/actualización y consultar su resultado durable |
| `GET/POST /sales/drafts`, `GET/PUT /sales/drafts/:cartId` | Listar, crear, recuperar y editar cestas con control de versión |
| `POST /sales/drafts/:cartId/pause`, `/resume`, `/cancel` | Gestionar la continuidad o cancelación de la cesta |
| `POST /pricing/quotes`, `/pricing/discount-authorizations` | Cotizar y registrar aprobación separada para un descuento limitado |
| `POST /sales/cash-confirmations` | Confirmar efectivo con identidad de comando, versión y cotización vigente |
| `GET /commands/:commandId` | Recuperar el resultado terminal `completed` o `rejected` de la confirmación |
| `GET /sales/:saleId` | Consultar el comprobante histórico, con detalle y reglas conservadas |

[TASK-412](https://github.com/developer-implementos/pos-platform/issues/412), integrada en `main` con [pos-platform#413](https://github.com/developer-implementos/pos-platform/pull/413) y [#414](https://github.com/developer-implementos/pos-platform/pull/414), retiró `POST /auth/login` y agregó la activación de equipos y el login con prueba de posesión que describe el [ADR-23](decisions/device-activation.md):

| Rutas de TASK-412 | Responsabilidad |
| --- | --- |
| `POST /auth/activations`, `POST /auth/installation-credentials` | Activar un equipo: token de un solo uso con `installation.activate` y vínculo de la llave pública a una instalación del mismo canal |
| `POST /auth/challenges`, `POST /auth/installation-login` | Emitir un desafío de un solo uso e iniciar sesión con la firma del equipo; la caja se deriva de la instalación |
| `GET /administration/installations`, `POST /administration/installations/:installationId/deactivate` | Consultar el equipo de cada caja y desactivarlo con `installation.manage` |

Con una contraseña marcada para cambio obligatorio, el servidor solo admite consultar la sesión, cambiar la contraseña y cerrar sesión (`PASSWORD_CHANGE_REQUIRED`).

[TASK-416](https://github.com/developer-implementos/pos-platform/issues/416), integrada con [pos-platform#418](https://github.com/developer-implementos/pos-platform/pull/418), reemplazó el usuario por el correo en el login, en la activación con la cuenta y en el alta y la edición de operadores (`email`, con `OPERATOR_EMAIL_TAKEN` para un correo repetido), agregó a cada operador su origen y la referencia opcional al trabajador del ERP, y agregó la activación con un código de un solo uso que describe el [ADR-24](decisions/email-sign-in.md):

| Rutas de TASK-416 | Responsabilidad |
| --- | --- |
| `POST /administration/installations/:installationId/activation-codes` | Generar con `installation.activate` un código de diez minutos y un solo uso para el equipo de una caja; reemplaza el código abierto de esa caja |
| `POST /auth/activation-code-redemptions` | Canjear el código desde un cliente del mismo canal y vincular la llave pública del equipo a esa instalación; todo rechazo responde igual |

[TASK-406](https://github.com/developer-implementos/pos-platform/issues/406) retiró `POST /auth/lab/login` (`labLoginV1`) con el perfil de laboratorio ([ADR-25](decisions/single-operational-mode.md)): responde 404 y todo inicio de sesión exige la llave del equipo. `GET /api/v1` informa `mode: operational` y la configuración efectiva `profile: operational`; ambos campos conservan ese único valor para los clientes instalados antes del cambio. La [referencia de APIs](/guide/api/pos-platform/) contiene todas las operaciones de estas tablas, importadas del artefacto del producto.

Los comandos usan `contractVersion`, `commandId` y versión esperada cuando existe un agregado. Los importes viajan como cadenas decimales; UUID y fechas se normalizan en contrato. La identidad, permisos y capacidades se verifican en el servidor, independientemente de lo que muestre la UI. Los tokens de sesión se conservan en memoria en el cliente; el servidor guarda su hash y vencimiento.

F01-09 incorpora dos rutas v1 sin cambiar el DTO de cesta existente: `GET /sales/drafts/recoverable` lista las cestas propias pausadas en otros puestos de la misma sucursal; `POST /sales/drafts/:cartId/recover` toma una mediante `commandId` y `expectedVersion`. El destino se deriva de la sesión, no del cuerpo. La operación conserva el origen, valida la configuración de la instalación destino y exige una nueva cotización. La [guía F01](phase-1-laboratory.md#revisión-de-datos-y-recuperación-entre-puestos) explica la interacción, los conflictos y la frescura de clientes; la evidencia de este corte se registra en el producto.

Las rutas de negocio usan el prefijo `api` y el versionado URI nativo de Nest, con versión inicial `1`. Las sondas se declaran neutrales a versión y quedan fuera de ese prefijo. OpenAPI describe operaciones y DTO en español y usa `operationId` explícitos y estables para los consumidores del contrato.

## Logging, errores y límites HTTP

Cada aplicación backend se ejecuta en un proceso Node independiente. Dentro de ese proceso, Nest y HTTP comparten Pino mediante `nestjs-pino`, cuyo logger raíz se comparte a nivel de proceso; no se admite alojar dos aplicaciones Nest con configuraciones de logging diferentes en el mismo proceso. Cada solicitud recibe un identificador generado por el servidor, devuelto en `x-request-id` y `x-correlation-id`; no se adopta el ID enviado por el cliente. Los registros incluyen contexto de servicio y ambiente, y el registro de finalización HTTP agrega correlación, método, ruta, estado y duración. Se excluyen query, cuerpos y cabeceras; no se habilita un segundo registro automático de Fastify.

La protección de campos estructurados elimina las claves configuradas de credenciales, datos personales y solicitudes/respuestas en la raíz y hasta dos niveles de anidación. Los serializadores explícitos de `err`, `error` y `context` también se aplican al logger HTTP, con `wrapSerializers: false` para impedir que `pino-http` reinstale su serializador de errores. Los errores conservan solo un tipo genérico, y el contexto admite un nombre técnico acotado.

El hook `logMethod` reconoce las sobrecargas con `Error`, campos `err`/`error` o un `context` no técnico antes de que Pino derive `msg` desde la excepción. Las convierte en un evento con campos técnicos permitidos y el mensaje fijo `Operation failed`. Las pruebas cubren las sobrecargas reales de `Logger` y `PinoLogger`. Esta protección no sanitiza recursivamente cualquier objeto ni detecta secretos escritos dentro de un mensaje libre arbitrario. Los consumidores deben registrar eventos y campos técnicos expresamente elegidos, sin pasar DTO, objetos de proveedores ni texto del usuario. La captura opcional de Sentry conserva únicamente frames reducidos para diagnóstico.

En aplicaciones y contextos se inyecta el logger de `nestjs-pino`. El adaptador de plataforma puede usar el puente `Logger` de Nest configurado con el mismo destino; no debe introducirse otro logger independiente. Las pruebas comprueban niveles, contexto y redacción de valores sintéticos.

Durante la construcción del contenedor Nest, su logger permanece desactivado para no almacenar ni imprimir excepciones originales antes de configurar la protección. Después se conecta Pino y se registra un evento técnico de composición terminada; los fallos de arranque mantienen un mensaje público genérico.

Los errores HTTP mantienen una respuesta plana con cuatro campos:

| Campo       | Contrato                                                      |
| ----------- | ------------------------------------------------------------- |
| `code`      | Código estable para identificar el error                      |
| `message`   | Mensaje público del error; genérico para errores internos 500 |
| `category`  | Clasificación del error                                       |
| `timestamp` | Momento de la respuesta en formato ISO 8601                   |

Esta base no devuelve `details`, stacks ni el mensaje de una excepción interna. La correlación viaja en las cabeceras; no se duplica en el cuerpo del error. Los futuros códigos de negocio requerirán un contrato explícito antes de incorporarse.

Fastify limita el cuerpo a 1 MiB y configura `requestTimeout` en 30 segundos para recibir la solicitud. Ese plazo no cancela por sí mismo un caso de uso ni una llamada externa: esas operaciones necesitarán sus propios límites y cancelación. La aplicación también activa validación de DTO y cabeceras de seguridad; estos controles no sustituyen autenticación ni autorización.

## Reporte opcional de errores con Sentry

Esta sección describe la implementación integrada en `main` de POS Platform hasta `d55bad79c80f2743d46c46fdacfa448162633c77` (TASK-148). Sentry está deshabilitado por defecto y los cuatro `.env.example` dejan el DSN vacío. Activarlo requiere configurar deliberadamente las variables de la aplicación; esta entrega no conecta ningún proyecto real de Sentry. No cambia el estado de disponibilidad de la API ni habilita operaciones de negocio.

| Sufijo de variable                    | Valor por defecto | Uso                                                                   |
| ------------------------------------- | ----------------- | --------------------------------------------------------------------- |
| `SENTRY_ENABLED`                      | `false`           | Habilita el reporter; `true` exige un DSN válido                      |
| `SENTRY_DSN`                          | vacío             | Destino autorizado de los eventos, configurado fuera del repositorio  |
| `SENTRY_RELEASE`                      | vacío             | Versión opcional del despliegue, sin datos personales ni credenciales |
| `SENTRY_SHUTDOWN_TIMEOUT_MS`          | `2000`            | Límite de cierre y envío pendiente, entre 1 y 10000 ms                |
| `SENTRY_MAX_EVENTS_PER_HOUR`          | `1`               | Eventos distintos admitidos por hora y proceso, entre 1 y 1000        |
| `SENTRY_FINGERPRINT_COOLDOWN_SECONDS` | `3600`            | Espera antes de volver a reportar el mismo origen, entre 0 y 86400 s  |

Cada sufijo lleva el prefijo del proceso: `BRANCH_API_`, `COUNTRY_API_`, `BRANCH_SYNC_WORKER_` o `ERP_WORKER_`. Por ejemplo, `BRANCH_API_SENTRY_ENABLED=false` y `BRANCH_API_SENTRY_DSN=` mantienen deshabilitado el reporter de sucursal. El ambiente se obtiene de `NODE_ENV` y la identidad del servicio la fija la aplicación.

La captura ocurre una vez en fronteras explícitas: errores HTTP 5xx inesperados, fallos al crear o iniciar la aplicación después de validar su configuración y errores al inspeccionar el contexto del worker. No se reportan errores de validación/cliente ni el 503 esperado de readiness. Los argumentos de comando inválidos y los fallos anteriores a disponer de configuración válida se registran localmente; no dependen de un cliente Sentry todavía no configurado. Los workers siguen sin procesar jobs. No hay captura global de toda excepción del proceso, trazas distribuidas, profiling, replay ni exportación automática de logs.

El reporter construye un evento mínimo y `beforeSend` vuelve a limitar sus campos. Conserva códigos técnicos propios, fase, servicio, ambiente, release opcional, identificadores UUID de solicitud/correlación y estado HTTP cuando correspondan. Conserva hasta 40 frames de error, reducidos al nombre base del archivo y sus números de línea/columna. No envía el mensaje original de la excepción, stack bruto, rutas completas, URL, query, cuerpos, cabeceras, cookies, usuario, breadcrumbs ni objetos arbitrarios en `extra` o `contexts`.

Cada aplicación tiene su cliente privado, sin instalar integraciones automáticas ni modificar un SDK global compartido. El cierre es idempotente y acotado por el timeout configurado. Ese envío es de mejor esfuerzo: no constituye una cola durable ni garantiza entrega durante caída de red o terminación forzada. Los tests usan un transporte en memoria y valores sintéticos; no acreditan la recepción en un proyecto real de Sentry.

### Presupuesto de la cuota

La cuota de errores de Sentry pertenece a la organización, no a cada proyecto: el plan Developer da 5.000 errores al mes, unos 7 por hora. Cada proceso decide antes de construir el evento si vale la pena gastarla:

- **Enfriamiento por huella.** La huella combina fase, código técnico y frame de origen. Un mismo origen se reporta una vez por enfriamiento, así que un bucle que falla mil veces produce un evento y no mil.
- **Tope por hora.** Limita los eventos distintos que un proceso envía en una hora, aunque cada uno sea un problema nuevo. Por defecto es 1.

El presupuesto vive en la memoria de cada proceso y es el único límite que el POS aplica a la cuota. Sentry sólo ofrece límites de tasa por DSN en los planes Business y Enterprise, así que en el plan Developer nada más protege la cuota. Cuando se agota, Sentry rechaza los eventos.

**Dimensionamiento.** El peor caso es procesos × tope por hora × 720 horas al mes.

| Escenario | Procesos | Máximo con el tope por defecto |
| --- | --- | --- |
| Piloto (`branch-api`, `branch-sync-worker`, `country-api` y `erp-worker`) | 4 | 2.880 eventos al mes, bajo los 5.000 |
| Cada sucursal adicional | +2 (`branch-api` y `branch-sync-worker`) | +1.440 eventos al mes |
| Tres sucursales | 8 | 5.760 eventos al mes, sobre la cuota |

Como el tope mínimo es 1, desde la tercera sucursal hace falta un plan que aporte límites o un reparto distinto de la cuota.

Con 1 evento por hora, un segundo fallo distinto en la misma hora se descarta, y Pino conserva su registro local. Los eventos descartados no se cuentan en Sentry: el número de eventos de una issue indica cuántas veces se admitió, no cuántas ocurrió.

Los frames se reducen al nombre de archivo, línea y columna, con `abs_path` normalizado como `app:///<archivo>`. Si el artefacto se publicó con Debug IDs, el evento incluye sólo las imágenes `sourcemap` de los archivos presentes en sus frames. Con ellas, Sentry aplica el sourcemap subido sin depender del release.

### Fallos de los clientes conectados

Los clientes de escritorio y móvil no incluyen el SDK de Sentry, no reciben un DSN y no contactan servicios externos: la CSP de los artefactos sigue admitiendo sólo el origen de `branch-api`. En el perfil `branch`, el `ErrorHandler` de composición conserva el registro en consola y carga de forma diferida un normalizador. Ese normalizador reduce el fallo al sobre `client-failure-v1` de `@pos-platform/contracts`:

| Campo             | Contenido                                                                                     |
| ----------------- | --------------------------------------------------------------------------------------------- |
| `contractVersion` | `1`, la única versión que admite el servidor                                                  |
| `application`     | `pos-desktop` o `pos-mobile`                                                                  |
| `errorType`       | Clase estándar (`TypeError`, `RangeError`, `DOMException`…) u `Other`; nunca el mensaje       |
| `route`           | Plantilla de la configuración del router, como `administration/users/:userId`; nunca la URL   |
| `frames`          | Hasta 40 posiciones `{ file, line, column }`, con nombre de bundle sin host, ruta ni query    |
| `debugIds`        | Hasta 20 pares `{ file, debugId }`, sólo de los bundles presentes en los frames               |

El cliente lo envía a `POST /api/v1/telemetry/client-failures` (`reportClientFailureV1`) con la sesión de operador vigente. Deduplica por clase, ruta y frame de origen, y envía como máximo 10 reportes por carga de la aplicación. Si no hay sesión, si no hay conexión o si el envío falla, descarta el reporte sin reintentar ni guardarlo. El cliente sin configurar no registra el handler.

**Un `BranchApiError` nunca se reporta:**

- Si `branch-api` respondió con un error, el servidor ya recibió la solicitud.
- Si la conexión se interrumpió (`CONNECTION_INTERRUPTED`, por red o tiempo agotado), el relay tampoco recibiría el reporte, porque es el mismo `branch-api`.
- Una respuesta fuera del contrato (`INVALID_RESPONSE`) también se descarta, y ningún otro componente la reporta.

#### Lo que ve la persona

Desde [TASK-458](https://github.com/developer-implementos/pos-platform/issues/458), un fallo no queda en silencio y se muestra sin detalles técnicos: sin mensaje de la excepción, pila, URL ni valores de la ruta.

- **Código de referencia.** Un error 5xx de `branch-api` o una respuesta fuera del contrato muestran «Código de referencia» con los primeros 8 caracteres de su `x-request-id`, que la API expone por CORS. Soporte lo busca por prefijo en los registros y en el `requestId` de Sentry. Un rechazo 4xx no lo muestra: su mensaje ya dice qué hacer.
- **Error no controlado.** El `ErrorHandler` muestra un aviso (`role="alert"`) con «Volver al inicio», «Reintentar» y «Cerrar el aviso». «Reintentar» crea de nuevo la pantalla sin recargar la página, porque el token vive sólo en memoria y recargar termina la sesión. Su código de referencia es el `x-request-id` de la respuesta del relay al reporte, el mismo `requestId` del evento reenviado, así que el sobre `client-failure-v1` no cambia. Si el reporte no llegó, el aviso pide indicar la hora.
- **Módulo que no carga.** Ocurre, por ejemplo, cuando un despliegue reemplazó los archivos de `pos-web`. No se reporta como fallo: el cliente avisa que hay una versión nueva.

#### Versión del cliente

Al configurar un artefacto, `tools/connected-client-policy.mjs` calcula su identidad: el SHA-256 de las rutas y del contenido de cada archivo, con el `index.html` sin sus metadatos de despliegue. La escribe en el sello `client-build.json` (`schemaVersion: 1`, `release`) y en `<meta name="pos-client-release">` del propio `index.html`. El mismo build tiene la misma identidad en cualquier origen; cualquier cambio de un archivo da otra.

- `pos-web` compara su identidad con la que sirve su origen: cada 15 minutos mientras está visible y al volver a verse tras 5 minutos. También la compara ante una respuesta fuera de contrato.
- Una versión nueva se anuncia con un aviso que no bloquea (`role="status"`). «Actualizar ahora» recarga sólo cuando no hay trabajo en curso: un comando enviado sin respuesta, un cobro, una venta por confirmar o abierta con líneas, o una apertura de caja por confirmar. Si lo hay, el aviso dice qué terminar. Al recargar, la persona vuelve a ingresar y lo guardado en la sucursal se conserva.
- Escritorio y móvil instalan sus archivos: recargar no los actualiza, así que el aviso pide instalar la actualización.

Si el cliente no logra arrancar, una pantalla propia reemplaza la página en blanco. Muestra la marca, la causa (sin red, configuración del puesto o arranque de la aplicación), «Reintentar» y los datos para soporte: aplicación, versión corta, motivo y hora.

`branch-api` responde siempre `{ received: true }`, se reenvíe o no el reporte. Sin sesión responde 401. Si el sobre no cumple el contrato responde 422 `VALIDATION_ERROR`: campos extra, otra `contractVersion`, más de 40 frames o más de 20 Debug IDs.

Tras validar de nuevo el sobre, lo reenvía con un cliente privado separado a otro proyecto, como evento `javascript`. El reporter del backend y el relay usan el mismo presupuesto: un único tope por hora (`BRANCH_API_SENTRY_MAX_EVENTS_PER_HOUR`) y el mismo enfriamiento. Por eso el relay no cambia el dimensionamiento. Además, cada instalación del puesto tiene un tope por hora propio, para que un equipo ruidoso no consuma el presupuesto de la sucursal.

El servidor genera la correlación y no añade usuario, sesión, instalación ni release, porque no conoce la versión del build que falló. La simbolización usa los Debug IDs.

| Variable de `branch-api`                                        | Valor por defecto | Uso                                                          |
| --------------------------------------------------------------- | ----------------- | ------------------------------------------------------------ |
| `BRANCH_API_CLIENT_SENTRY_ENABLED`                              | `false`           | Habilita el relay; `true` exige un DSN válido                |
| `BRANCH_API_CLIENT_SENTRY_DSN`                                  | vacío             | DSN del proyecto de clientes, distinto del backend           |
| `BRANCH_API_CLIENT_SENTRY_SHUTDOWN_TIMEOUT_MS`                  | `2000`            | Límite del vaciado del cliente del relay al cerrar, entre 1 y 10000 ms |
| `BRANCH_API_CLIENT_SENTRY_MAX_EVENTS_PER_INSTALLATION_PER_HOUR` | `1`               | Tope por instalación, entre 1 y el tope compartido           |

`branch-api` no arranca si se define `BRANCH_API_CLIENT_SENTRY_RELEASE`, `BRANCH_API_CLIENT_SENTRY_MAX_EVENTS_PER_HOUR` o `BRANCH_API_CLIENT_SENTRY_FINGERPRINT_COOLDOWN_SECONDS`, aunque esté vacía. El relay no asigna release ni tiene presupuesto propio, y así una configuración que lo supone no pasa inadvertida.

### Sourcemaps con Debug IDs

Los builds Angular de producción no emiten sourcemaps. La configuración `production-sourcemaps` coincide con `production`, salvo por los mapas ocultos de scripts, que no añaden `sourceMappingURL`; una prueba impide que ambas diverjan. El comando `node tools/build-connected-client.mjs --target desktop|mobile --deployment <política> --sentry-sourcemaps` construye con esa configuración y ejecuta `tools/observability/sentry-sourcemaps.mjs` antes de configurar el artefacto. La herramienta sigue estos pasos:

1. Falla si un script todavía referencia su mapa, antes de subir o borrar nada.
2. Inyecta Debug IDs con la `@sentry/cli` fijada en el lockfile.
3. Sube los mapas al proyecto indicado.
4. Elimina todos los `.map` del artefacto, y falla si queda alguno.

Requiere `SENTRY_AUTH_TOKEN`, `SENTRY_ORG`, `SENTRY_PROJECT` y, para la región EU, `SENTRY_URL=https://de.sentry.io`. Todo se valida antes de compilar, y el token viaja en el entorno del proceso, nunca como argumento.

En el backend, el build por defecto conserva el comentario `sourceMappingURL`, que `nx serve` usa para traducir las trazas locales. Un release simbolizable usa la configuración `production-sourcemaps` de cada aplicación, que oculta ese comentario, y después ejecuta la herramienta:

```sh
pnpm nx run branch-api:build:production-sourcemaps
node tools/observability/sentry-sourcemaps.mjs --directory dist/apps/branch-api --release <id>
```

`--release` es opcional, porque la simbolización usa los Debug IDs. Si se indica, debe coincidir con `*_SENTRY_RELEASE`. Los mapas suben con su código fuente (`sourcesContent`): publicarlos en Sentry es una decisión del destino autorizado, igual que los eventos.

### Configuración recomendada en la capa gratuita

El plan Developer, consultado el 2026-11-11, incluye:

- 1 usuario;
- 5.000 errores al mes;
- 30 días de retención;
- alertas sólo por correo;
- ningún límite de gasto configurable ni límites de tasa por DSN;
- 1 monitor cron y 1 monitor uptime.

También incluye spans, replays y logs, que esta base no usa. Esta guía recomienda la configuración siguiente, que se aplica en la interfaz de Sentry. Ninguna parte de esta entrega conecta un proyecto real.

- **Región y organización.** Elegir US o EU al crear la organización. La región no se cambia después y debe autorizarla seguridad, junto con la retención.
- **Dos proyectos.** `node` para las cuatro apps backend y `javascript` para el relay de clientes, cada uno con su DSN, para separar agrupación, sourcemaps y alertas. El ambiente procede de `NODE_ENV`. El reporter se habilita sólo en el piloto y en producción, nunca en el ambiente local ni en la CI.
- **Cuota.** El plan no admite límites por DSN, así que el tope del POS es el control. Antes de sumar una sucursal, revisar el dimensionamiento.
- **Privacidad del proyecto.** Activar el depurador de datos con los patrones por defecto y la opción de no almacenar direcciones IP. Es una defensa adicional: la allowlist del POS ya excluye esos datos.
- **Token de CI.** Un token de organización sólo para subir sourcemaps y releases, guardado como secreto del pipeline de release.
- **Alertas.** Reglas por correo de issue nueva y de regresión, con el equipo responsable que defina F05-06.
- **Monitores.** Reservar el monitor uptime para la readiness pública de un servicio desplegado, cuando exista. El monitor cron no se usa mientras los workers no programen trabajos.

Traces, session replay, logs y métricas siguen deshabilitados. Profiling y Seer no forman parte del plan gratuito. Habilitar cualquiera de ellos requiere el requisito y la revisión de privacidad de F05-06 y F05-09: un replay de caja contendría clientes, montos y medios de pago.

## Verificación

```sh
pnpm run api:test
pnpm run api:check
pnpm run api:smoke
```

`api:check` ejecuta los targets Nx `lint`, `typecheck`, `test` y `build` de `branch-api`.

Las pruebas usan Vitest y SWC con metadata de decoradores para la inyección de Nest. Los casos HTTP y de persistencia requieren PostgreSQL real aislado mediante `POS_TEST_ADMIN_URL` y preparan su sucursal con `provision`, `activate-checkout` e `import-commercial`, como QA; las pruebas puras no requieren ese servicio. Se verifican permisos, ámbitos, versiones, concurrencia y recuperación. Rspack/SWC genera el bundle distribuible; TSC comprueba tipos por separado.

El smoke del artefacto lo instala fuera del monorepo con `pnpm install --prod --frozen-lockfile`, para detectar dependencias resueltas accidentalmente desde el workspace. Migra una base aislada con roles sintéticos y comprueba los comandos de migración y comprobación, el arranque por HTTPS, la autenticación, la readiness y los logs. La instalación requiere acceso al registro npm. Los checks de Sentry usan transporte en memoria y canarios sintéticos, sin enviar eventos a un servicio real.

El job `api` de CI ejecuta `backend:check`, `structure:check` y `backend:smoke`, separado de los jobs del frontend y escritorio. Cubre las cuatro aplicaciones backend y sus librerías; los comandos `api:*` siguen disponibles para trabajar solo sobre `branch-api`.

Para abarcar las cuatro aplicaciones backend y sus librerías, usar `pnpm run backend:check`, `pnpm run backend:build` y `pnpm run backend:smoke`. `pnpm run structure:check` verifica las reglas arquitectónicas. La comprobación de cada worker solo acredita su composición y cierre; todavía no hay transporte o jobs de negocio que probar.

La comprobación del artefacto también captura los logs del proceso: exige una sola entrada de finalización por solicitud, correlación compartida entre Nest y HTTP y ausencia de valores sensibles sintéticos enviados en headers, query, cuerpo y rutas desconocidas.

## Artefacto y ejecución

```sh
pnpm run api:build
```

El resultado se genera en `dist/apps/branch-api`: bundle de aplicación y librerías internas, `package.json` y lockfile con las dependencias externas del runtime. La entrega del servicio utiliza esa carpeta, sin copiar el `node_modules` completo del monorepo ni publicar las librerías fuente por separado. Las demás aplicaciones backend generan su propio artefacto bajo `dist/apps/<aplicación>`.

En el destino, desde la carpeta del artefacto:

```sh
pnpm install --prod --frozen-lockfile
node --env-file=/ruta/api.env main.js
```

El comando requiere una base previamente migrada y aprovisionada, credenciales runtime y el certificado y la llave TLS. No hay otro perfil: la sucursal y los usuarios propios POS salen siempre de la provisión. Cambiar `NODE_ENV` no habilita capacidades comerciales: las controla la configuración efectiva y sus contratos. El archivo de configuración es externo al artefacto y no se versiona. El CLI `database.js` ejecuta migraciones con la credencial separada; el servidor no hace auto-migraciones.

Esta API es un proceso Node independiente dentro de **pos-platform**. La configuración `vercel.json` del repositorio editorial **pos-docs** publica únicamente Starlight; no publica `branch-api` ni las demás aplicaciones backend. El despliegue del backend de sucursal necesita su propia supervisión de proceso, terminación TLS, identidad y política de acceso antes de incorporar operaciones reales.

## Evolución prevista

La organización distingue infraestructura compartida de propiedad de negocio: conexiones y ejecutores técnicos en `shared/backend`; modelos, repositorios y migraciones en cada contexto. Los contratos comerciales se publican desde su contexto; `shared/contracts` contiene sobres, metadatos y errores transversales, no un catálogo global de DTO de negocio.

La venta en efectivo tiene autenticación, autorización, PostgreSQL, migraciones y una unidad de trabajo que conserva sus efectos y outbox, sobre identidades propias y provisión real. Sus datos comerciales entran por `import-commercial`; en las pruebas, desde una publicación ficticia. La CLI legacy de `erp-worker` consulta referencias puntuales mediante HTTPS y cuenta técnica propia; no publica maestros ni cotiza. La entrega de outbox, recepción de país, espejos completos, jobs BullMQ y ERP permanecen en sus fases. F02 añade persistencia y protocolo de pagos, fiscalidad y dispositivos, sin acreditar sus proveedores ni hardware operativos. Las reglas CL sintéticas no homologan Chile, Perú o España. Los clientes hablan con la API y nunca consultan SQL directamente.

La [propuesta de arquitectura](propuesta-arquitectura.md) y las [opciones tecnológicas](opciones-tecnologicas.md) explican la ubicación del backend y los límites del perfil sin WAN. El servicio no promete autonomía de una caja ante caída de la LAN o del servidor de sucursal.

## Referencias técnicas

- [Adaptador oficial Fastify de NestJS](https://docs.nestjs.com/techniques/performance): integración HTTP; los plugins y middleware deben ser compatibles con Fastify.
- [nestjs-pino](https://github.com/iamolegga/nestjs-pino): integración del logger de Nest y contexto de solicitudes.
- [Clientes y scopes aislados de Sentry](https://docs.sentry.io/platforms/javascript/best-practices/shared-environments/): patrón de cliente manual sin `Sentry.init()` global; su ejemplo de navegador se adapta aquí a `NodeClient` y se comprueba con el SDK Node instalado.
- [Integraciones de Sentry para Node](https://docs.sentry.io/platforms/javascript/guides/node/configuration/integrations/): instrumentación y contexto que pueden añadir los plugins; el cliente manual del POS usa una lista vacía y captura explícita.
- [Filtrado de eventos de Sentry](https://docs.sentry.io/platforms/javascript/guides/node/configuration/filtering/): uso de `beforeSend` antes de enviar eventos; la base POS reconstruye sus campos permitidos.
- [Debug IDs de sourcemaps](https://docs.sentry.io/platforms/javascript/sourcemaps/troubleshooting_js/debug-ids/): asociación entre bundle y mapa independiente del release, usada por clientes y backend.
- [Planes y cuotas de Sentry](https://sentry.io/pricing/): límites del plan Developer, consultados el 2026-11-11.
- [Gestión del flujo de eventos de Sentry](https://docs.sentry.io/pricing/quotas/manage-event-stream-guide/#rate-limiting): los límites de tasa por DSN sólo existen en los planes Business y Enterprise; consultado el 2026-11-11.
- [Opciones del servidor Fastify](https://fastify.dev/docs/latest/Reference/Server/): límites de cuerpo y tiempo de recepción de solicitudes.
- [Preparar aplicaciones para despliegue con Nx](https://nx.dev/docs/guides/ci-deployment): generación del manifiesto y lockfile del artefacto para instalar sus dependencias fuera del workspace.
- [Rspack con Nx](https://nx.dev/docs/technologies/build-tools/rspack/introduction): integración del empaquetador con el workspace y sus tareas.
- [Ejecutores TypeScript/Node de Nx](https://nx.dev/docs/technologies/typescript/executors): ejecución del resultado de compilación y tareas de empaquetado.
