# F02 · Cobros, documentos y dispositivos

**Implementación parcial integrada en `main`.** F02 incorpora persistencia y contratos de pagos, fiscalidad y dispositivos en `branch-api`, y el host nativo `apps/device-agent`. Las pruebas usan PostgreSQL, SQLite y HTTPS reales con datos aislados. Los adaptadores de pago y facturación son exclusivos de pruebas, sin conexión a proveedores; el host publicado no incluye un driver físico habilitado. Este corte no habilita cobros con tarjeta, emisión fiscal ni impresión operativa.

La base de este corte está integrada en `main`, en la [revisión `98f8987` de POS Platform](https://github.com/developer-implementos/pos-platform/tree/98f8987bfa8764ab77f6a55a7686f2ed7884d541). La [matriz técnica de F02](https://github.com/developer-implementos/pos-platform/blob/98f8987bfa8764ab77f6a55a7686f2ed7884d541/delivery/reviews/F02-verification.md) conserva las comprobaciones de la base y sus pendientes; el [informe de F02-13](https://github.com/developer-implementos/pos-platform/blob/98f8987bfa8764ab77f6a55a7686f2ed7884d541/delivery/reviews/F02-13-verification.md) acredita la recuperación comercial incorporada después. Los incrementos siguientes identifican sus propias revisiones. El avance se consulta en el [panel del proyecto](/project/), con su revisión de producto identificada. La aceptación humana y la habilitación operativa se informan por separado.

Los incrementos integrados incorporan el seguimiento conectado, la búsqueda y descarga protegida del original fiscal, el cobro combinado y la recuperación comercial. Las PR enlazadas conservan las comprobaciones y resultados de cada incremento. Publicar esta guía no acredita por sí solo una ejecución aprobada de CI, el guardado físico de archivos desde una WebView nativa ni la habilitación operativa del producto.

**Cobro combinado integrado:** efectivo y transferencia manual, activación explícita de puestos, bandeja de verificación y recuperación del plan. Backend, frontera HTTP y pruebas focales del cliente aprobaron sus comprobaciones. El recorrido E2E con dos operadores también aprobó; su revisión y límites se identifican en la evidencia al final de esta guía.

El [roadmap F02](/guide/roadmap/phase-02/) conserva los catorce entregables y sus criterios. La implementación de un contrato, una prueba o un binario no completa por sí sola toda la fase. La revisión técnica y el avance se registran en POS Platform; la publicación de esta guía no implica aceptación humana.

**Historial integrado:** [TASK-110](https://github.com/developer-implementos/pos-platform/issues/110) reúne la evidencia por operación. La [PR #117](https://github.com/developer-implementos/pos-platform/pull/117) está integrada en `main`, en la [revisión `3669873`](https://github.com/developer-implementos/pos-platform/commit/36698736acdf9f7968d4538810e5ac73dee36ab6), y la historia está cerrada.

**Expedientes integrados:** [TASK-114](https://github.com/developer-implementos/pos-platform/issues/114) añade responsables y cierre documentado. La [PR #118](https://github.com/developer-implementos/pos-platform/pull/118) está integrada en `main`, en la [revisión `6e679f6`](https://github.com/developer-implementos/pos-platform/commit/6e679f692aab1fa5681688f1ffae651a215c2d81), y la historia está cerrada. Estos incrementos no completan por sí solos [F02-04](https://github.com/developer-implementos/pos-platform/issues/26) ni registran aceptación humana.

La revisión `9695bd9` aprobó los **35 controles de CI local**, con árbol limpio y revisión estable, y los siete controles de GitHub. La [PR #118](https://github.com/developer-implementos/pos-platform/pull/118) conserva la evidencia y sus límites. La recuperación conectada aprobó **3 de 3 recorridos**: recuperación comercial, [evidencia por operación](https://github.com/developer-implementos/pos-platform/blob/9695bd9d45d9db2e48c410123c5e630085c4144f/tests/pos-clients-e2e/operational/operation-evidence.spec.ts) y [expedientes con dos supervisores](https://github.com/developer-implementos/pos-platform/blob/9695bd9d45d9db2e48c410123c5e630085c4144f/tests/pos-clients-e2e/operational/operation-cases.spec.ts). Comprueban estados independientes, paginación, errores de consulta, respuesta perdida después de persistir, recuperación del mismo comando y conflicto de versión. La [actualización hasta `242_operation_cases`](https://github.com/developer-implementos/pos-platform/blob/9695bd9d45d9db2e48c410123c5e630085c4144f/apps/branch-api/test/migration-upgrade.integration.test.ts) conserva datos previos y compara esquema, restricciones y privilegios con una instalación nueva. Los recorridos usan API HTTPS y PostgreSQL aislados con datos sintéticos; no acreditan proveedores ni hardware reales.

## Incrementos integrados

Los siguientes incrementos están integrados en `main`, hasta la [revisión `6e679f6`](https://github.com/developer-implementos/pos-platform/tree/6e679f692aab1fa5681688f1ffae651a215c2d81). Cada fila conserva la revisión que lo incorporó. El avance del portal procede de su snapshot de producto; integrar una PR parcial no verifica automáticamente su entregable.

| Incremento | Revisión de producto | Resultado acotado |
| --- | --- | --- |
| F02-07 · Admisión de proveedores | [PR #93](https://github.com/developer-implementos/pos-platform/pull/93), commit [`1350ad6`](https://github.com/developer-implementos/pos-platform/commit/1350ad626d0acb3dacc576aa8378fff5ab6fad42) | Rechazar perfiles incompatibles antes de reservar saldo, conservando el destino de los pagos pendientes |
| F02-12 · Exportación de originales en Windows | [PR #94](https://github.com/developer-implementos/pos-platform/pull/94), commit [`d5d5e5f`](https://github.com/developer-implementos/pos-platform/commit/d5d5e5f30fe44f2c2c64fec3e45ba3fe7e3b6d01) | Guardado mediante un comando Tauri restringido y un diálogo del sistema, con resultados de guardado y cancelación diferenciados |
| F02-13 · Historial y consulta de compensaciones | [PR #95](https://github.com/developer-implementos/pos-platform/pull/95), commit [`afdd23b`](https://github.com/developer-implementos/pos-platform/commit/afdd23b0e52cd205ea16bc0b39f6bd557dc79e02) | Consultar el historial y recuperar el resultado de una compensación existente sin volver a despacharla |
| F02-13 · Recuperación comercial y revisión durable | [PR #96](https://github.com/developer-implementos/pos-platform/pull/96), commit [`23a1cb8`](https://github.com/developer-implementos/pos-platform/commit/23a1cb80c3db4ac010ce7aba93132da3025c3877) | Completar la venta existente, reservar y ejecutar por separado una compensación o registrar revisión operativa sin duplicar efectos |
| F02-04 · Historial de evidencia por operación (TASK-110) | [PR #117](https://github.com/developer-implementos/pos-platform/pull/117), commit [`3669873`](https://github.com/developer-implementos/pos-platform/commit/36698736acdf9f7968d4538810e5ac73dee36ab6) | Consultar evidencia cronológica autorizada y estados independientes de venta, pago, fiscalidad y dispositivos, sin ejecutar efectos |
| F02-04 · Expedientes de excepciones (TASK-114) | [PR #118](https://github.com/developer-implementos/pos-platform/pull/118), commit [`6e679f6`](https://github.com/developer-implementos/pos-platform/commit/6e679f692aab1fa5681688f1ffae651a215c2d81) | Asignar responsables y conservar conclusiones operativas con evidencia, permisos explícitos y control de concurrencia, sin modificar estados financieros |

Las PR conservan sus comprobaciones y límites. Las pruebas del código nativo, la verificación del artefacto y el recorrido dentro de Tauri conservan evidencia separada; no se deducen de las pruebas del frontend. F02-07 y F02-12 mantienen los pendientes descritos en esta guía. F02-13 cuenta con la verificación de sus cuatro criterios de software; no acredita homologación bancaria ni aceptación humana.

Entre el 16 y el 17-11-2026 se integraron los incrementos siguientes, hasta la [revisión `6eb9804`](https://github.com/developer-implementos/pos-platform/tree/6eb980489cc936f6f81fb3a57cbf65501658ad45). La composición operativa de `branch-api` sigue sin adaptadores de pago ni de terminal: lo que depende de un proveedor responde como no disponible, y el adaptador real sigue en [FOLLOWUP-002](/project/attention/#followup-002) y [FOLLOWUP-004](/project/attention/#followup-004). La [CI de `main` sobre `6eb9804`](https://github.com/developer-implementos/pos-platform/actions/runs/44002489011) aprobó las pruebas de la API y los recorridos conectados de cobro combinado, recuperación y consultas. Cerrar estas tareas no verifica sus entregables ni registra aceptación humana.

| Incremento | Revisión de producto | Resultado acotado |
| --- | --- | --- |
| F02-05 · Redondeo legal del efectivo (TASK-366) | [PR #368](https://github.com/developer-implementos/pos-platform/pull/368), commit [`80e0f0c`](https://github.com/developer-implementos/pos-platform/commit/80e0f0c40650b3526125a41c8cc83b79b9f55516) | Política pura por país en `libs/country-policies`, sin consumidores en pagos, ventas ni caja; el [ADR-20](decisions/cash-rounding.md) sigue en propuesta |
| F02-07 · [Perfiles de pago del puesto](#perfiles-de-pago-y-su-ejecutabilidad) (TASK-363) | [PR #369](https://github.com/developer-implementos/pos-platform/pull/369), commit [`b9164c1`](https://github.com/developer-implementos/pos-platform/commit/b9164c1f25227eae727e83d538297fd9655a543e) | Listar los perfiles vigentes con su ejecutabilidad, calculada con el mismo diagnóstico que la admisión |
| F02-04 · [Bandeja de efectos sin resolver](#bandeja-de-efectos-sin-resolver) (TASK-364) | [PR #371](https://github.com/developer-implementos/pos-platform/pull/371), commit [`635b643`](https://github.com/developer-implementos/pos-platform/commit/635b64363fa6c2a589032d4ca2a2f2ef2c499fff) | Localizar pagos, compensaciones, documentos e impresiones sin resolver, sin ejecutar efectos |
| F02-07 · [Canal de notificación y kit de conformidad](#canal-de-notificación-y-kit-de-conformidad) (TASK-367) | [PR #370](https://github.com/developer-implementos/pos-platform/pull/370), commit [`8728d6e`](https://github.com/developer-implementos/pos-platform/commit/8728d6e36567a12a9af10d2cfd7729ddf8d706c2) | Rechazar en la admisión un canal declarado sin verificador; kit de pruebas para adaptadores |
| F02-14 · [Estado y mantenimiento del terminal](#estado-y-mantenimiento-del-terminal-de-pago) (TASK-365) | [PR #372](https://github.com/developer-implementos/pos-platform/pull/372), commit [`d6c0d14`](https://github.com/developer-implementos/pos-platform/commit/d6c0d144aa3ee3fedfe70fc139df056a34679a02) | Consultar el estado sin efectos y registrar mantenimientos idempotentes; uno incierto excluye el terminal |
| F02-01 · [Cobro con tarjeta en la caja conectada](#cobro-con-tarjeta-desde-la-caja-conectada) (TASK-375) | [PR #378](https://github.com/developer-implementos/pos-platform/pull/378), commit [`f3d2713`](https://github.com/developer-implementos/pos-platform/commit/f3d2713b328b425ca078a172b0b923a1d487691c) | Ofrecer tarjeta sólo con un perfil ejecutable y recuperar el mismo comando sin otro cobro |
| F02-06 · [Voucher manual de tarjeta](#voucher-manual-de-tarjeta) (TASK-377) | [PR #379](https://github.com/developer-implementos/pos-platform/pull/379), commit [`e260b8f`](https://github.com/developer-implementos/pos-platform/commit/e260b8f143160ad94798c5da92eecc0a2c192736) | Registrar un voucher una sola vez por comercio, terminal y código, con verificador independiente si la política lo declara |
| F02-14 · [Cierre del lote del terminal](#cierre-del-lote-del-terminal) (TASK-376) | [PR #380](https://github.com/developer-implementos/pos-platform/pull/380), commit [`db49e43`](https://github.com/developer-implementos/pos-platform/commit/db49e43f4d002b2492b2d759deee1196f7e5c956) | Cerrar el lote sin tocar la caja y recuperar su resultado sin repetirlo |

El 23-11-2026 se integraron los incrementos siguientes. Cada fila cita el commit que lo incorporó a `main`. Cerrar estas tareas no verifica sus entregables ni registra aceptación humana.

| Incremento | Revisión de producto | Resultado acotado |
| --- | --- | --- |
| F02-10 · [Reimpresión autorizada](#reimpresión-autorizada-de-un-documento) (TASK-581) | [PR #588](https://github.com/developer-implementos/pos-platform/pull/588), commit [`2bcff89`](https://github.com/developer-implementos/pos-platform/commit/2bcff892ce23748c43fe93b825d43070cd50864c) | Reimprimir un documento existente con el permiso `device.reprint` y un motivo, sin otra venta, pago ni documento |
| F02-06 · [Bloqueo de la venta sin verificador](#consulta-al-verificador-y-bloqueo-de-la-venta) (TASK-658) | [PR #680](https://github.com/developer-implementos/pos-platform/pull/680), commit [`13b0e59`](https://github.com/developer-implementos/pos-platform/commit/13b0e59f280e1ebda4a92eb907720a2ef0f70be2) | Rechazar al aprovisionar una política `block-sale` sin verificador autorizado (`verifier-not-authorized`) y registrar las consultas fallidas |
| Mantenimiento del host (TASK-655) | [PR #672](https://github.com/developer-implementos/pos-platform/pull/672), commit [`8a9b191`](https://github.com/developer-implementos/pos-platform/commit/8a9b191b221da652c67837dd27606fe060662681) | [Leer acotado el cuerpo de error](#respuestas-de-error-y-compatibilidad-del-host) y aplazar el acuse sólo ante un trabajo retenido |

## Aplicaciones y autoridad

| Pieza | Implementación y estado | Límite |
| --- | --- | --- |
| `branch-api` · `payments` | Intenciones e intentos durables, destino fijo, consulta y compensación separada. El incremento añade plan, asignaciones y verificación manual de transferencias en PostgreSQL; después, perfiles con su ejecutabilidad, voucher manual, estado y mantenimiento del terminal y cierre de lote | Sin adaptador Transbank ni de terminal compuesto; no interpreta una respuesta desconocida como rechazo seguro ni una declaración como dinero confirmado |
| `branch-api` · `fiscal` | Solicitud y fuente inmutable, identidad autorizada, intento de envío, consulta y estados diferenciados | Sin emisor/material fiscal habilitado ni adaptador Acepta/Ingydev operativo; no genera folios ficticios |
| `branch-api` · `devices` | Inscripción y asignación por puesto, trabajos, recepción, permiso de ejecución de un uso y resultados durables | No ejecuta drivers Windows ni convierte un recibo local en documento fiscal |
| `branch-api` · `reporting` | Historial de evidencia y expedientes con responsables e historial durable integrados mediante TASK-110 y TASK-114; bandeja de efectos sin resolver de TASK-364 | Lee mediante contratos propietarios; las decisiones del expediente no modifican estados financieros ni trabajos físicos |
| `device-agent` | Host C#/.NET independiente del cliente, HTTPS saliente y registro SQLite por instalación | Publicación Windows x64 comprobada; driver runtime no disponible. Instalación como servicio, firma, cuenta y hardware requieren su evidencia |
| `pos-desktop` / `pos-mobile` | Perfiles conectados, seguimiento paginado, historial por operación, expedientes y recuperación de comandos; en `pos-desktop`, tarjeta condicionada a un perfil ejecutable, voucher manual, bandeja y terminales de pago | Sin perfil ejecutable no ofrece tarjeta, y la composición actual no tiene ninguno; no completa resolución de excepciones ni acredita entrega nativa de documentos |

`country-api`, los workers, BullMQ y Redis no intervienen en el recorrido local del host. La coordinación del puesto usa HTTPS y persistencia en sucursal; no necesita una cola Redis en el PC. La [decisión de dispositivos](decisions/device-agent.md) fija la ubicación por puesto y la evolución de dispositivos de red en F06.

## Qué conserva cada contexto

### Historial de evidencia por operación

**TASK-110 · integrado en `main` mediante la [PR #117](https://github.com/developer-implementos/pos-platform/pull/117).**

Desde **Seguimiento de operaciones**, el detalle reúne la evidencia de la venta, los pagos, los documentos fiscales y la impresión. Cada efecto conserva su estado: un pago aprobado puede coexistir con fiscalidad pendiente o una impresión incierta. El panel no resume esa combinación como un éxito global.

`reporting` compone consultas públicas de los contextos propietarios dentro de una lectura consistente de PostgreSQL. No crea una segunda autoridad financiera, no consulta proveedores y no vuelve a ejecutar comandos. El permiso del registro seleccionado permite entrar a su detalle; cada efecto adicional exige su propio permiso y ámbito. La vista distingue registros disponibles, ausencia de registros vinculados, falta de permiso y relación que no puede establecerse. Un error de consulta tampoco se presenta como ausencia de evidencia.

El historial usa hechos que ya se conservaron: creación, intentos, observaciones, confirmación local y recepción o resultado de dispositivos. No reconstruye transiciones inexistentes. Ordena por la hora registrada en sucursal y una identidad estable; cuando existe una hora observada por el proveedor o el dispositivo, la muestra por separado. El estado actual aparece en su propio resumen, no como si hubiera sido el resultado original de todos los eventos anteriores.

La paginación conserva una revisión del conjunto autorizado. Si cambia la evidencia mientras se recorren sus páginas, el cliente solicita actualizarla en lugar de mezclar versiones. Un fallo de red conserva los registros ya consultados con un aviso; un cambio de sesión o de permisos limpia la vista. La consulta tiene límites explícitos por operación y falla de forma visible si se exceden, sin presentar un historial truncado como completo.

El panel de evidencia sólo ofrece actualizar la evidencia. Los controles de recuperación existentes conservan sus permisos y confirmaciones propios. La [historia TASK-110](https://github.com/developer-implementos/pos-platform/issues/110) conserva su evidencia de entrega; su cierre no completa por sí solo la resolución integral de excepciones de F02-04. El [catálogo HTTP](/guide/api/pos-platform/) identifica la revisión de los contratos publicados, separada del estado de integración de cada incremento.

### Autoridad del seguimiento de excepciones

**TASK-114 · integrado en `main` mediante la [PR #118](https://github.com/developer-implementos/pos-platform/pull/118), revisión [`6e679f6`](https://github.com/developer-implementos/pos-platform/commit/6e679f692aab1fa5681688f1ffae651a215c2d81).**

El perfil inicial reserva la asignación y el cierre de expedientes a supervisores con permisos explícitos. Un expediente conserva una conclusión operativa y su evidencia; cerrarlo no aprueba un pago, no libera una reserva, no emite un documento ni confirma una impresión. La solicitud original de revisión de pago conserva su identidad e inmutabilidad.

La [historia TASK-114](https://github.com/developer-implementos/pos-platform/issues/114) implementa ese seguimiento sobre el historial común. Los permisos se habilitan de forma expresa y se asignan mediante roles; el nombre «supervisor» por sí solo no concede facultades. Las reglas de Tesorería y fiscalidad del piloto mantienen sus validaciones específicas.

| Acción | Permiso explícito | Información conservada |
| --- | --- | --- |
| Consultar expedientes y su historial | `operation.case.read` y permisos sobre la evidencia original | Operación, evidencia de apertura, responsable, estado y decisiones de seguimiento |
| Abrir un expediente o cambiar su responsable | `operation.case.assign`, además de consulta | Motivo, identidad del supervisor, responsable habilitado y versión del expediente |
| Registrar una conclusión y cerrar el expediente | `operation.case.resolve`, además de consulta | Conclusión, referencia de evidencia y autor; los estados del pago, documento e impresión permanecen a cargo de sus contextos |

El expediente pertenece al ámbito de sucursal, puesto e instalación. Cada incidente se identifica por la operación y el evento que motivó su apertura: repetir ese mismo incidente no crea otro expediente, incluso después de cerrarlo. Una nueva evidencia permite abrir otro seguimiento. El historial conserva los hechos originales de apertura, asignación y cierre; no permite reescribirlos ni borrar un expediente cerrado.

El directorio ofrece personas activas del ámbito con permisos de expediente. Antes de asignar, el servidor comprueba además que el destinatario pueda consultar el ancla y la evidencia original; no basta tener un rol de supervisor. Una fuente de venta reservada a su autor no se vuelve visible por asignar un expediente. Si el destinatario no tiene acceso, la asignación se rechaza sin cambiar al responsable anterior. Las consultas, comandos y recuperación de respuestas vuelven a comprobar los permisos vigentes y la visibilidad de la evidencia, incluida la utilizada para cerrar.

Dos supervisores pueden consultar el mismo expediente, pero sus cambios llevan la versión que leyeron. Si uno lo modifica antes, el otro debe actualizar la consulta; no se sobrescribe su decisión. Si se pierde una respuesta, el cliente conserva la identidad del comando pendiente y recupera ese mismo resultado, sujeto nuevamente a autorización. No genera otra asignación ni otro cierre como sustituto silencioso.

`reporting` es propietario de estas decisiones operativas durables. Sus proyecciones de lectura pueden reconstruirse; el historial de expedientes debe conservarse y respaldarse. El [diccionario de datos](/guide/api/data-model/) y el catálogo HTTP muestran lo exportado desde la revisión integrada del producto que identifican. Este seguimiento no sustituye la revisión de Tesorería ni habilita proveedores.

**Pagos:** el backend inmoviliza la cesta y la cotización vinculadas al intento, conserva el destino y excluye operaciones incompatibles sobre el mismo terminal. Guarda el intento antes de llamar al proveedor. Una respuesta perdida exige consultar o conciliar el intento original; no permite cobrar con otra clave para salir de la incertidumbre. Si llega evidencia contradictoria después de liberar un rechazo, la cuarentena se conserva tanto para el terminal como para la cesta: liberar el intento anterior no vuelve seguro otro cobro o la confirmación en efectivo. Si la venta ya se confirmó antes de conocer el conflicto, conserva su evidencia; no la borra ni deshace un movimiento externo por cambiar el estado local. La compensación tiene su propia intención, importe reservado, destino e intento. El plan combinado coordina las asignaciones sin habilitar una reversa operativa con un adquirente ausente.

**Fiscalidad:** la solicitud conserva una fuente comercial inmutable y la identidad fiscal autorizada. Los estados del proveedor y de la autoridad tributaria se distinguen. Consultar no vuelve a emitir; la ausencia o vencimiento de identidad impide el envío. Las restricciones locales de unicidad no acreditan numeración legal global ni sustituyen el material fiscal o las reglas del país. La composición actual no habilita un numerador ni un proveedor productivo.

**Dispositivos:** PostgreSQL es la autoridad de asignación, trabajo y permiso de ejecución. SQLite conserva recepción, intento y evidencia pendiente en el puesto. No contiene ventas ni un espejo comercial y no se usa como archivo de logs. Los logs diagnósticos del servicio son separados y no incluyen credenciales o payloads completos.

### Admisión de proveedores

La [PR #93](https://github.com/developer-implementos/pos-platform/pull/93) comprueba que el perfil de un pago nuevo coincida con un adaptador compuesto en **proveedor, versión de adaptador y versión de contrato**. Exige cobro habilitado y los métodos de consulta o compensación que el perfil declara. Lo hace antes de reservar el presupuesto del plan o la venta y antes de crear la intención. Una configuración por sí sola no instala un adaptador; la composición operativa de `branch-api` mantiene el registro bancario vacío.

Si la combinación no está soportada, devuelve `PROVIDER_CAPABILITY_UNAVAILABLE` y el diario conserva el rechazo sin intención ni saldo reservado. Repetir ese `commandId` devuelve el mismo rechazo, incluso después de corregir la composición. Un nuevo intento de admisión necesita un comando nuevo y explícito. Esta regla no autoriza repetir un cobro externo incierto.

Un recibo de admisión anterior mantiene su resultado. Consultar o recuperar un pago pendiente utiliza su **snapshot original**, incluidas cuenta, terminal, versión y referencia de credencial; no lo redirige al perfil de reemplazo ni vuelve a aplicarle los controles de admisión del perfil nuevo. El proceso necesita conservar el adaptador correspondiente para ejecutar esa consulta.

Esta comprobación es local: no llama al proveedor, no prueba conectividad o credenciales y no homologa la semántica de un método por el hecho de existir. La matriz de proveedores, sus contratos y los canales de evidencia restantes conservan su alcance en F02-07.

### Perfiles de pago y su ejecutabilidad

**TASK-363 · integrado en `main` mediante la [PR #369](https://github.com/developer-implementos/pos-platform/pull/369), revisión [`b9164c1`](https://github.com/developer-implementos/pos-platform/commit/b9164c1f25227eae727e83d538297fd9655a543e).**

`GET /api/v1/payment-profiles` (`listPaymentProfilesV1`) devuelve, para la sucursal y la caja de la sesión, la revisión vigente de cada perfil con su destino público, `executable` y `reasonCodes`: `profile-disabled`, `adapter-unavailable` o `capability-unsupported`. Exige `payment.read` y no selecciona la referencia de credencial ni expone direcciones o secretos. Una caja con más de 50 perfiles vigentes responde `CONFIGURATION_INCOMPATIBLE` en lugar de truncar la lista.

La ejecutabilidad sale del mismo diagnóstico que la admisión: `PROVIDER_CAPABILITY_UNAVAILABLE` se produce exactamente cuando ese diagnóstico informa un motivo. La lista es orientativa. Crear la intención vuelve a resolver la revisión vigente y a comprobarla, de modo que un perfil listado como ejecutable que deja de serlo se rechaza sin reservar saldo. Con la composición actual, todo perfil sale no ejecutable con `adapter-unavailable`.

La PR conserva sus pruebas en PostgreSQL, con un adaptador controlado que sólo existe en ellas, y en la frontera HTTP. El incremento no decide [Q-18](/project/questions/#q-18) ni [Q-83](/project/questions/#q-83), y no acredita la homologación de [FOLLOWUP-002](/project/attention/#followup-002) ni de [FOLLOWUP-003](/project/attention/#followup-003). Cerrar la tarea no verifica [F02-07](https://github.com/developer-implementos/pos-platform/issues/29).

### Canal de notificación y kit de conformidad

**TASK-367 · integrado en `main` mediante la [PR #370](https://github.com/developer-implementos/pos-platform/pull/370), revisión [`8728d6e`](https://github.com/developer-implementos/pos-platform/commit/8728d6e36567a12a9af10d2cfd7729ddf8d706c2).**

Las capacidades del destino admiten un campo opcional `notification`: `channelRef`, un identificador de contrato que nunca es una dirección; `authentication`, `signature` o `mutual-tls`, y `deduplication`, `provider-event-id`. Si falta, la evidencia llega por la respuesta o por la consulta declarada. Los destinos guardados antes de este campo se leen sin migrar. Un perfil que declara un canal cuyo adaptador no expone el verificador se rechaza con `PROVIDER_CAPABILITY_UNAVAILABLE` antes de reservar saldo o crear la intención, y la [lista de perfiles](#perfiles-de-pago-y-su-ejecutabilidad) lo informa como `capability-unsupported`. No hay un receptor de notificaciones: el verificador no se invoca, y una notificación sin verificar no es evidencia financiera.

El [kit de conformidad](https://github.com/developer-implementos/pos-platform/tree/6eb980489cc936f6f81fb3a57cbf65501658ad45/libs/backend/payments/test/conformance) es sólo de pruebas y corre contra cualquier adaptador. Comprueba la correlación por clave de operación y destino, el importe y la moneda exactos, que la llamada termine poco después de cancelarla, que una respuesta tardía se recupere sólo por su clave, que un acuse perdido nunca se informe como éxito y que cada canal declarado tenga verificador. Pasar el kit no homologa un proveedor. Qué proveedores ofrecen notificación, y con qué autenticidad, protección contra repeticiones y rotación, sigue en [FOLLOWUP-002](/project/attention/#followup-002) y [FOLLOWUP-003](/project/attention/#followup-003). El criterio de F02-07 sobre esos canales no tiene evidencia hasta que exista uno real.

## Cobro combinado y transferencia manual

La recomendación adoptada permite avanzar con reglas explícitas del primer perfil: **una moneda por plan, importes exactos, vuelto sólo de efectivo y verificación manual autorizada de transferencias**. Implementar y probar esas reglas no queda condicionado a un documento formal de Finanzas. La habilitación de cuentas, permisos y puestos para operar dinero real sigue siendo una decisión de despliegue identificada.

El plan guarda una versión de la cesta, su cotización, configuración y turno. Mientras está abierto, la cesta no se edita, recotiza ni confirma por otra ruta de cobro. Cada asignación distingue importe aplicado, recibido y vuelto. Una transferencia declarada reserva saldo, pero no cuenta como confirmada; una tarjeta incierta tampoco deja ese saldo libre para cobrarlo con otro medio.

Por ejemplo, para un total de **1.190 CLP**, pueden aplicarse **400 CLP en efectivo** y **790 CLP por transferencia verificada**. Si el cajero recibe 500 CLP, el vuelto es 100 CLP y la caja registra 400 CLP. La suma aplicada debe coincidir exactamente con el total; la API no redondea una diferencia para completar el pago. Si todo se paga por transferencia, no se crea un pago ni movimiento ficticio de efectivo.

Confirmar el plan escribe en una sola transacción la venta, sus asignaciones, caja, auditoría y outbox. Los contextos conservan sus datos y se coordinan mediante puertos públicos. El recibo muestra las asignaciones; `SaleConfirmed` v2 las identifica para sincronización, manteniendo lectores compatibles con el evento v1. La venta sigue siendo un comprobante local: pagar no emite automáticamente un documento fiscal ni registra el ERP.

### Quién verifica una transferencia

La cuenta receptora se provisiona fuera del runtime. El cajero elige una cuenta autorizada y registra referencia, importe y moneda; no introduce libremente otra cuenta como destino. El estado inicial es `declared`. Un operador con permiso específico compara los datos observados y confirma o rechaza con motivo. Por defecto debe ser **otro operador**; la cuenta puede admitir el mismo operador sólo por configuración propietaria explícita.

`manually-confirmed` acredita la decisión manual auditada del POS, no una respuesta bancaria. `reconciled` registra la conciliación posterior y no aplica el dinero por segunda vez. Un verificador ausente o una declaración pendiente no se transforman en aprobación por timeout. Las discrepancias conservan lo observado; no se reemplazan por los valores esperados para fabricar una coincidencia.

La referencia normalizada no puede usarse de nuevo en otra venta dentro de la sucursal. La cuenta y su namespace tienen alcance **`branch-exclusive`**: se asignan exclusivamente a esa base de sucursal. Esta garantía no es deduplicación corporativa entre bases desconectadas; no se habilitan cuentas compartidas entre sucursales sin una autoridad común que controle las aplicaciones. La base tampoco identifica por sí sola dos alias bancarios que representan una misma cuenta.

La evidencia estructurada conserva cuenta, referencia, importe, operador, decisión y motivo. El backend incorpora una bandeja de declaraciones por verificar y confirmaciones manuales por conciliar, accesible con el permiso específico aunque el verificador no pueda registrar pagos. Mantiene sucursal, puesto e instalación y paginación vinculada al estado; no restringe la revisión al creador del pago.

La migración 239 conserva un PDF opcional privado de hasta **512 KiB**, con hash y metadatos inmutables en PostgreSQL. Sólo el registrador autorizado puede adjuntarlo; un lector, verificador o conciliador habilitado del ámbito puede consultarlo. El permiso de registrar no concede por sí solo descarga. Un reenvío conserva ID y contenido; adjuntar no confirma ni vuelve a aplicar el pago. Se comprobaron acceso, límites, integridad, inmutabilidad y bytes/cabeceras de descarga mediante PostgreSQL y HTTP; también las reglas del cliente. El archivo se descarga como adjunto y permanece `not-scanned`: no demuestra liquidación ni se presenta la validación de formato como análisis antimalware.

### Consulta al verificador y bloqueo de la venta

**TASK-658 · integrado en `main` mediante la [PR #680](https://github.com/developer-implementos/pos-platform/pull/680), revisión [`13b0e59`](https://github.com/developer-implementos/pos-platform/commit/13b0e59f280e1ebda4a92eb907720a2ef0f70be2).** Endurece la política de verificación por cuenta receptora que incorporó [TASK-568](https://github.com/developer-implementos/pos-platform/pull/571), en la revisión [`6ecc549`](https://github.com/developer-implementos/pos-platform/commit/6ecc5497484625a4906cccfa80a5b2635f83d498).

El propietario aprovisiona la política de cada cuenta receptora con `database.js provision-transfer-verification-policy`, fuera del runtime. La política es inmutable y declara el contrato del verificador autorizado, o ninguno, su plazo de respuesta y qué ocurre mientras la verificación no se resuelve:

| Política | Mientras la transferencia no se resuelve |
| --- | --- |
| `keep-sale-pending` | El importe queda reservado y la venta admite otros medios |
| `block-sale` | La asignación queda incierta y se detienen otros medios, cargos, la finalización y la cancelación hasta la decisión manual |

Sólo se consulta un verificador que la sucursal compone para el contrato declarado. Hoy `branch-api` no compone ninguno, así que toda consulta queda pendiente con su motivo y nunca confirma ni rechaza por sí sola. Un plazo vencido aborta la consulta y la registra sin decidir.

Como salvaguarda técnica, el aprovisionamiento rechaza `block-sale` con el código fijo `verifier-not-authorized` mientras la sucursal no componga un verificador para ese contrato, incluido un contrato nulo, y lo hace antes de escribir. Sin ella, cada transferencia a esa cuenta dejaría la venta sin poder finalizarse ni cancelarse. `keep-sale-pending` sigue disponible, y una política ya aprovisionada no cambia. Los demás rechazos del comando también usan códigos fijos (`branch-mismatch`, `scope-mismatch`, `document-invalid` y `revision-content-conflict`), con código de salida 1.

Una consulta inaccesible, vencida o con respuesta inválida emite el evento técnico `payment.transfer.verification.failed`, con un motivo fijo y el contrato del verificador. No incluye importe, cuenta, referencia, evidencia ni actor.

La salvaguarda no es una regla de negocio. Si una cuenta sin verificador autorizado puede bloquear la venta lo decide Tesorería en [FOLLOWUP-036](/project/attention/#followup-036). Si lo admite, el comando deberá aceptarlo con un aviso explícito al operador. No hay un verificador bancario real compuesto.

### Recuperación y devolución de efectivo

El cliente conserva el comando pendiente con su ID y payload, separados del token de sesión. Ante respuesta perdida recupera o reenvía explícitamente **el mismo comando**; no genera otra identidad para intentar cobrar de nuevo. La API comprueba permiso y asignación vigentes dentro de la transacción, incluso al recuperar un recibo. Cambiar de sesión limpia los datos visibles sin borrar la identidad del pendiente.

Preparar un plan o añadir dinero exige las capacidades habilitadas. Finalizar fondos ya admitidos, consultar o devolver efectivo no depende de volver a habilitar una capacidad para admitir fondos nuevos; conserva sus permisos y validaciones. Tampoco se recalcula silenciosamente una cotización congelada después de recibir el pago. Si no puede completarse, se mantiene un estado recuperable y la compensación conserva su propio contrato.

Cancelar un aporte de efectivo exige confirmar que se devolvió **todo lo recibido** y registrar el motivo. La devolución queda como evidencia inmutable. Un plan no se cancela para ocultar fondos externos confirmados, declaraciones pendientes o resultados inciertos. La interfaz de este incremento permite efectivo y transferencia; la tarjeta se ofrece sólo con un perfil ejecutable, según el [cobro con tarjeta desde la caja conectada](#cobro-con-tarjeta-desde-la-caja-conectada).

### Activación del puesto

La provisión operativa mantiene sus cuatro capacidades iniciales: `catalog.read`, `customer.read`, `draft.write` y `pricing.quote`. Migrar el esquema no concede por sí solo permisos de cobro. El propietario de despliegue utiliza el CLI separado de la API:

```text
node dist/apps/branch-api/database.js activate-checkout --file "<ruta absoluta del JSON>"
node dist/apps/branch-api/database.js provision-transfer-receiver --file "<ruta absoluta del JSON>"
```

El documento de activación declara `activationId`, `branchId`, `approvedBy`, permisos explícitos para el rol administrador y los puestos afectados. Cada puesto incluye `expectedConfigurationVersion`, capacidades y **todas** sus instalaciones activas con ID, época y capacidades del cliente. El servidor aplica control de versión, comprueba el administrador habilitado, publica una revisión inmutable y revoca las sesiones afectadas. Los roles ordinarios no reciben permisos adicionales por activar el puesto.

Las capacidades adicionales soportadas son `shift.open`, `sale.cash`, `payment.plan` y `payment.transfer.manual`, con sus dependencias. Activarlas no crea maestros ni precios. Los puertos de consulta de catálogo/precios verifican una publicación comercial completa y coherente en el ámbito, moneda y versión requeridos; una fuente ausente conserva `SOURCE_UNAVAILABLE`. La importación autorizada desde archivo está [en revisión](/guide/architecture/master-data-publication/#carga-desde-archivo-en-la-sucursal) en TASK-404, sin integrar, y el extractor del legacy (TASK-405) mantiene su alcance pendiente; las semillas de las pruebas no se cargan en una sucursal operativa.

La cuenta declara `receiverAccountId`, `accountRef`, `bankRef`, `currency`, `scale`, `referenceNamespace` y `referenceScope: "branch-exclusive"`. La provisión exige `exclusiveBranchAcknowledged: true` y usa `requiresIndependentVerifier: true` por defecto. Los JSON se entregan desde archivos externos, sin secretos bancarios en el repositorio; el proceso HTTP no recibe la credencial SQL propietaria.

Las migraciones 235–238 añaden planes/asignaciones, evidencia de transferencia, snapshot congelado de ventas y registro de activación. Conservar respaldos, historial y recibos al actualizar. Ante un fallo se detienen nuevas admisiones y se recuperan los pendientes; no se borran evidencias para volver a cobrar. Un binario anterior que no entiende ventas y eventos v2 no es una reversión compatible después de escribirlos.

### Cobro con tarjeta desde la caja conectada

**TASK-375 · integrado en `main` mediante la [PR #378](https://github.com/developer-implementos/pos-platform/pull/378), revisión [`f3d2713`](https://github.com/developer-implementos/pos-platform/commit/f3d2713b328b425ca078a172b0b923a1d487691c).** Cambia sólo el cliente: consume los contratos de intenciones y la [lista de perfiles](#perfiles-de-pago-y-su-ejecutabilidad) ya publicados.

El bloque «Tarjeta» del plan ofrece el cobro sólo si la capacidad `payment.card` está activa, la sesión tiene `payment.read`, `payment.create` y `payment.execute`, y la lista incluye al menos un perfil ejecutable. Si no, oculta la opción y muestra el motivo, incluidos los `reasonCodes` del servidor. Con la composición actual todo perfil sale `adapter-unavailable` y la tarjeta no se ofrece; la API rechaza igualmente una admisión intentada por otra vía.

El cajero elige el perfil y el importe. El cliente crea la intención con el plan, la cesta, la cotización y la versión del plan, y la ejecuta con la versión vigente. Cada comando lleva su `commandId` y queda en un diario local, sin credenciales ni datos del cliente. Ante una respuesta perdida, **Recuperar misma solicitud** reenvía el comando guardado sin crear otra intención ni otro intento; recargar no lo reenvía solo. Una intención admitida y sin despachar se cobra o se retira desde el mismo bloque, después de consultar su estado.

El aviso repite el estado que devuelve el servidor: sólo `approved` dice que el cobro se confirmó, `declined` permite elegir otro medio, y `uncertain`, `dispatching` y `reconciliation-required` piden no cobrar de nuevo. Una asignación con tarjeta `uncertain` o `reconciliation-required` bloquea otro cobro con tarjeta en la venta y enlaza a la [consulta del efecto original](#consulta-explícita-del-efecto-original) en Seguimiento de operaciones.

Sin adaptador no existe un recorrido conectado de un cobro aprobado: la evidencia son las pruebas del store y del componente contra el contrato. La [CI de `main`](https://github.com/developer-implementos/pos-platform/actions/runs/44002489011) aprobó el recorrido conectado de cobro combinado, que comprueba que la opción no existe sin perfil ejecutable. El incremento no decide [Q-74](/project/questions/#q-74) y no acredita el terminal ni el adaptador de [FOLLOWUP-002](/project/attention/#followup-002). Cerrar la tarea no verifica [F02-01](https://github.com/developer-implementos/pos-platform/issues/23).

### Voucher manual de tarjeta

**TASK-377 · integrado en `main` mediante la [PR #379](https://github.com/developer-implementos/pos-platform/pull/379), revisión [`e260b8f`](https://github.com/developer-implementos/pos-platform/commit/e260b8f143160ad94798c5da92eecc0a2c192736).**

Un pago con tarjeta hecho en un terminal no integrado se registra en el plan como asignación `card-voucher`, con código de autorización, últimos 4 dígitos, importe y terminal. Lo hace `POST /api/v1/payment-plans/:planId/card-vouchers` (`registerCardVoucherV1`), que exige `payment.voucher.record`, la capacidad `payment.plan`, `commandId` y la versión esperada del plan. El contrato no tiene campo para el número completo de la tarjeta, y tampoco se guardan su vencimiento ni su código de seguridad.

**La capacidad nace apagada.** La política de cada terminal (`payments.card_voucher_policy`) declara el modo de confirmación, `on-registration` o `independent-verifier`, y el patrón del código, sin valores por defecto. La aprovisiona el rol propietario con `database.js provision-card-voucher-policy --file <ruta>`, como la cuenta receptora de la transferencia. Sin una política admisible, la API responde `CARD_VOUCHER_UNAVAILABLE`; `GET /api/v1/payment-card-voucher-policies` informa `admissible` y sus motivos. Un código que no cumple el patrón responde `CARD_VOUCHER_FORMAT_INVALID`, y un importe mayor que el saldo o en otra moneda, `PAYMENT_RESULT_MISMATCH`.

El mismo voucher, identificado por comercio, terminal y código, no se acepta en otra venta, tampoco con solicitudes concurrentes ni después de rechazarlo: responde `CARD_VOUCHER_ALREADY_USED`. Como la referencia de una transferencia, la unicidad vale dentro de la base de la sucursal; no hay una autoridad central entre sucursales. Con `independent-verifier`, el voucher queda `declared`, reserva el importe e impide finalizar la venta. Otro usuario con `payment.voucher.verify` lo confirma o rechaza desde «Verificación de vouchers manuales», en Seguimiento de operaciones (`GET /api/v1/payment-card-vouchers` y `POST /api/v1/payment-card-vouchers/:evidenceId/verify`). El servicio, una restricción y un disparador de PostgreSQL impiden que lo verifique quien lo registró.

La migración aditiva `250_card_vouchers` agrega la política, la evidencia y la verificación. `card-voucher` se suma a los métodos de las asignaciones del plan y de la venta pagada, y por lo tanto de `SaleConfirmed` v2. Ningún rol recibe `payment.voucher.record` o `payment.voucher.verify` por defecto. El voucher todavía no aparece en el historial de evidencia por operación, y su vista no tiene un recorrido de navegador conectado: la evidencia son las pruebas en PostgreSQL, HTTP y del cliente que conserva la PR.

El incremento no decide [Q-73](/project/questions/#q-73), [Q-109](/project/questions/#q-109), [Q-83](/project/questions/#q-83) ni [Q-57](/project/questions/#q-57). El formato del código del adquirente sigue en [FOLLOWUP-002](/project/attention/#followup-002) y la conciliación con el adquirente, en [FOLLOWUP-015](/project/attention/#followup-015). Cerrar la tarea no verifica [F02-06](https://github.com/developer-implementos/pos-platform/issues/28).

## Seguimiento conectado

La ruta `/operations` presenta tres listados independientes: **Pagos**, **Documentos fiscales** y **Dispositivos**. El operador puede filtrar por estado, recorrer páginas y abrir un detalle. El incremento añade la bandeja de revisión de transferencias descrita arriba, con acciones explícitas y permisos propios. Con sus permisos, la misma ruta muestra también la [bandeja de efectos sin resolver](#bandeja-de-efectos-sin-resolver), los [terminales de pago](#estado-y-mantenimiento-del-terminal-de-pago) y la [verificación de vouchers manuales](#voucher-manual-de-tarjeta). La pantalla consulta datos persistidos mediante la API de sucursal; no activa una demo si la consulta falla. Las secciones disponibles dependen de los permisos de la sesión, que la API vuelve a exigir.

| Sección | Consulta y permiso | Ámbito de lectura |
| --- | --- | --- |
| Pagos | `GET /api/v1/payment-intents`, filtro `state`, permiso `payment.read` | Sucursal, puesto e instalación del cliente de la sesión |
| Documentos fiscales | `GET /api/v1/fiscal/documents`, filtros de fecha, cliente, folio, tipo y `status`; permiso `fiscal.read` | Sucursal, entidad legal y país de la sesión; conserva el alcance de la consulta por ID |
| Dispositivos | `GET /api/v1/device-jobs`, filtro `state`, permiso `device.read` | Sucursal, puesto e instalación del cliente de la sesión; no se confunde con la instalación del host |

Los listados admiten hasta 50 registros por página. Ordenan por fecha de creación e identificador descendentes y conservan la precisión temporal de PostgreSQL; el cursor está vinculado al ámbito y al filtro. El detalle usa la consulta autorizada del mismo contexto. Ninguna de estas lecturas invoca al proveedor, concede permisos al host ni ejecuta cobros, emisiones, compensaciones o reimpresiones.

El seguimiento permite conocer el estado persistido, con estos límites:

- **Pago:** el importe mostrado pertenece a la intención original. No representa un saldo neto después de devoluciones ni resume todas las compensaciones. Resolverlas requiere su evidencia y su flujo propio.
- **Documento fiscal:** el estado aceptado o rechazado puede coexistir con evidencia contradictoria posterior. El listado presenta el estado actual; el historial del detalle permite consultar la evidencia persistida. Los metadatos y la disponibilidad del PDF original son datos separados; la descarga exige contenido conservado y autorización adicional.
- **Dispositivo:** `spooled` acredita recepción por el spooler, no salida física del papel. Consultar un resultado incierto no vuelve a ejecutar el trabajo.

Este incremento integrado aporta parte de **F02-04** y **F02-12**. El [historial por operación](#historial-de-evidencia-por-operación) y los [expedientes con responsables](#autoridad-del-seguimiento-de-excepciones) están integrados. **F02-04 sigue incompleto:** falta completar las acciones de recuperación por efecto que exigen sus criterios y comprobar los runbooks de resultado desconocido, rechazo, fallo conocido y pérdida de LAN en el entorno acordado. Cerrar un expediente no ejecuta esas acciones. La aceptación humana se registra por separado; la búsqueda y descarga fiscal tampoco acreditan un proveedor fiscal operativo ni el guardado desde las WebView nativas.

### Bandeja de efectos sin resolver

**TASK-364 · integrado en `main` mediante la [PR #371](https://github.com/developer-implementos/pos-platform/pull/371), revisión [`635b643`](https://github.com/developer-implementos/pos-platform/commit/635b64363fa6c2a589032d4ca2a2f2ef2c499fff).** La PR se declaró parcial porque su recorrido de navegador no se ejecutó antes de integrar. La [CI de `main` sobre `6eb9804`](https://github.com/developer-implementos/pos-platform/actions/runs/44002489011) aprobó después la suite conectada de recuperación, que lo incluye.

`GET /api/v1/operation-exceptions` (`listOperationExceptionsV1`) lista los efectos que su contexto propietario deja sin resolver. La sección «Efectos sin resolver» de Seguimiento los muestra sin necesidad de conocer su identificador:

| Efecto | Estados listados | Permiso |
| --- | --- | --- |
| Pago con tarjeta y compensación | `uncertain`, `reconciliation-required` | `payment.read` |
| Documento fiscal | `unknown`, `rejected` | `fiscal.read` |
| Trabajo de impresión | `uncertain` | `device.read` |

Cada fila trae el registro de origen y su ancla de evidencia, que en una compensación es su cobro, la fecha de origen, la antigüedad respecto de la hora de PostgreSQL (`asOf`), `reasonCodes` y `allowedActions`. Las acciones sólo abren lecturas existentes: el [historial de evidencia](#historial-de-evidencia-por-operación) y, con `operation.case.read`, los [expedientes](#autoridad-del-seguimiento-de-excepciones). La bandeja no consulta proveedores ni ejecuta cobros, emisiones o impresiones. `coverage` declara por efecto si se incluyó, si no se pidió o si quedó excluido por permiso, de modo que una bandeja vacía no se lea como «todo resuelto». Filtrar un efecto sin su permiso responde 403.

Las tres lecturas ocurren en una transacción `REPEATABLE READ READ ONLY`, y los permisos se vuelven a comprobar después. El orden es la fecha de origen y el identificador. El cursor es opaco y queda ligado al actor, el ámbito, los permisos y el filtro; uno alterado responde 422. Un efecto que cambia de estado entre páginas no se duplica. Los estados `dispatching` o `executing` detenidos no se listan.

La bandeja no asigna responsables ni agrega acciones de recuperación, que dependen de [Q-76](/project/questions/#q-76) y [FOLLOWUP-005](/project/attention/#followup-005). La conciliación de los pagos inciertos con el adquirente es [Q-09](/project/questions/#q-09). Este incremento no completa F02-04.

### Consulta explícita del efecto original

[TASK-165](https://github.com/developer-implementos/pos-platform/issues/165), integrado mediante la [PR #171](https://github.com/developer-implementos/pos-platform/pull/171) en [`bf05f73`](https://github.com/developer-implementos/pos-platform/commit/bf05f73ef36b891e2114150ec63bd3ba453e4d19), añade **Consultar efecto original al proveedor** al detalle del pago y del documento fiscal. La acción busca evidencia del mismo efecto mediante su destino conservado; no crea otro cobro, emisión ni compensación. Los propietarios `payments` y `fiscal` autorizan y ejecutan sus comandos; `reporting` conserva su función de lectura.

El servidor ofrece la acción según el estado persistido, el permiso vigente, el contrato de consulta y la disponibilidad del adaptador exacto del destino original. Explica por qué no está disponible sin sustituir el proveedor por el perfil comercial actual. La disponibilidad es orientativa: al admitir o recuperar el comando se revalidan autorización, ámbito y condiciones aplicables. Sin los contratos y adaptadores operativos, el control permanece deshabilitado; este incremento no acredita homologación ni habilitación productiva.

Abrir o actualizar detalle, evidencia o disponibilidad sólo lee la sucursal. La consulta al proveedor exige una acción explícita. Ante una respuesta perdida, **Recuperar consulta original** conserva el mismo comando dentro de la misma sesión; recargar no envía otro automáticamente. La referencia queda separada por API, ámbito, actor, sesión y operación. Después de la consulta, el operador actualiza detalle y evidencia para revisar el resultado persistido; un recibo de comando no equivale a aprobación financiera o fiscal. El [procedimiento del operador](https://github.com/developer-implementos/pos-platform/blob/bf05f73ef36b891e2114150ec63bd3ba453e4d19/libs/backend/fiscal/README.inquiries.md#procedimiento-del-operador) mantiene los pasos para incertidumbre, rechazo, pérdida de LAN y sesión expirada.

### Historial de compensaciones y consulta del resultado

**Incremento integrado de [F02-13](https://github.com/developer-implementos/pos-platform/issues/35), relacionado con [F02-04](https://github.com/developer-implementos/pos-platform/issues/26).** Amplía el detalle de un pago en `/operations` con sus anulaciones y reembolsos registrados. La lectura funciona aunque el adaptador del proveedor no esté disponible. La creación y ejecución tienen contratos separados, descritos en el incremento de recuperación comercial; consultar no acredita una integración bancaria operativa.

La [PR #95](https://github.com/developer-implementos/pos-platform/pull/95), integrada en [`afdd23b`](https://github.com/developer-implementos/pos-platform/commit/afdd23b0e52cd205ea16bc0b39f6bd557dc79e02), conserva la evidencia de cliente, arquitectura, tipos, compilación, PostgreSQL y recorridos integrados. Estas comprobaciones no se presentan como una verificación completa de F02-13. El proveedor de las pruebas es contractual y aislado: no acredita un adquirente real.

| Acción del operador | Contrato y permiso | Qué hace |
| --- | --- | --- |
| Abrir el historial, actualizar o cargar otra página | `GET /api/v1/payment-intents/:paymentIntentId/compensations`, `payment.read` | Lee PostgreSQL sin llamar al proveedor. Devuelve compensaciones, acciones disponibles y motivos de indisponibilidad. |
| Consultar resultado al proveedor | `POST /api/v1/payment-compensations/:compensationId/reconcile`, `payment.reconcile` | Consulta la compensación original por su identidad; no vuelve a enviarla ni crea otra devolución. |
| Recuperar una consulta cuya respuesta no llegó | El mismo POST, con el mismo `commandId`, compensación y `expectedVersion` | Recupera la solicitud durable sin sustituirla por una nueva identidad. Requiere autorización vigente. |

Cada registro muestra tipo, importe, estado, fecha, identificador y referencia confirmada cuando existe. El importe del pago original permanece separado: una página de compensaciones no permite calcular un saldo neto. Este historial reúne **compensaciones**, no todas las observaciones o intentos internos del proveedor.

El servidor ofrece `inquire` sólo para estados `dispatching`, `uncertain` o `reconciliation-required`, con permiso efectivo y consulta por `operation-key` declarada en el contrato original. También exige que esté registrado el adaptador de ese proveedor con las mismas versiones de adaptador y contrato, y que implemente la consulta. El POST vuelve a comprobar estas condiciones y la versión del registro: `allowedActions` describe la disponibilidad al leer, no es una autorización que pueda reutilizarse indefinidamente. Cambiar el perfil vigente no cambia el destino de una compensación existente.

| Estado mostrado | Interpretación operativa |
| --- | --- |
| Pendiente de envío | La compensación está reservada; consultar su historial no la despacha. La ejecución requiere el flujo explícito de recuperación. |
| Envío en curso / Resultado desconocido | No hay confirmación suficiente para afirmar que se devolvió dinero. Consultar sólo cuando el servidor lo permita. |
| Anulación confirmada / Reembolso confirmado | Existe evidencia confirmada de esa compensación; no implica una nueva venta ni una nota de crédito. |
| Rechazada por el proveedor | Se conserva el rechazo registrado, separado del estado del pago original. |
| Requiere conciliación | Existe un conflicto que mantiene la cuarentena. Una consulta puede añadir evidencia, pero no levanta esa cuarentena automáticamente. |

**Recuperación:** ante una respuesta perdida, el operador puede actualizar los registros o recuperar explícitamente la misma consulta. El cliente conserva sólo la referencia mínima del comando, aislada por API, usuario, puesto, instalación y pago; no almacena token, credenciales ni respuesta del proveedor. Bloquea otra consulta del mismo pago mientras el pendiente no se recupere. Una recarga no ejecuta POST automáticamente. Los cambios de selección, sesión o permisos invalidan respuestas tardías y limpian los datos visibles; la API sigue siendo la autoridad de acceso y estado.

Si falta permiso, capacidad de consulta o adaptador, el historial explica el motivo. No ofrece un botón que marque manualmente dinero devuelto. Si la consulta devuelve incertidumbre o falla la actualización del historial, no se presenta una confirmación ficticia. El índice aditivo `240_compensation_lookup_index` permite recorrer las compensaciones por pago, fecha e identificador; el cursor mantiene la precisión temporal de PostgreSQL y queda ligado al pago y al ámbito autorizado. La migración no cambia estados ni concede permisos.

**Despliegue y reversión:** programar una ventana controlada y pausar nuevas admisiones durante la actualización. Ejecutar primero el migrador con el rol propietario y el manifiesto de la nueva versión; después iniciar `branch-api` compatible y comprobar su readiness antes de reabrir el tráfico. La 240 usa `CREATE INDEX` dentro de la transacción de migración, sin `CONCURRENTLY`, y puede bloquear escrituras de compensaciones mientras se construye. Este procedimiento no acredita una actualización gradual sin interrupción. La sonda exige coincidencia exacta de IDs y checksums de todas las migraciones: el binario anterior cuyo manifiesto termina en la 239 no queda listo sobre esa base actualizada. Para retirar el comportamiento nuevo se necesita una compilación de reversión que conserve el manifiesto hasta la 240 y los contratos ya persistidos. No borrar el registro de la migración, alterar checksums ni eliminar evidencia para forzar la aceptación de un binario antiguo.

La recuperación comercial reutiliza `finalize`, recibos durables de comando y la transacción que confirma venta y outbox. El incremento siguiente reúne la prueba conjunta de tarjeta aprobada, fallo real de finalización y reinicio, y el flujo del operador para recuperar, compensar o solicitar revisión aunque el pago todavía no tenga compensaciones registradas.

La homologación del adquirente es una condición operativa separada; no sustituye la prueba de recuperación ni justifica duplicar los mecanismos existentes. La vista integral de incidentes fiscales/dispositivos conserva su propio alcance. Las devoluciones comerciales de ventas finalizadas y sus notas de crédito pertenecen a **F04**. La verificación de F02-13 reúne este historial con el flujo y la evidencia descritos a continuación.

### Recuperación de venta y compensación explícita

**Implementación integrada y técnicamente verificada de [F02-13](https://github.com/developer-implementos/pos-platform/issues/35).** Amplía el detalle del pago con un flujo para completar la venta existente o solicitar y ejecutar una compensación autorizada. La aprobación del cobro y la confirmación de la venta siguen siendo hechos diferentes. Las devoluciones de una venta ya confirmada pertenecen a F04.

La [PR #96](https://github.com/developer-implementos/pos-platform/pull/96), integrada en [`23a1cb8`](https://github.com/developer-implementos/pos-platform/commit/23a1cb80c3db4ac010ce7aba93132da3025c3877), contiene este incremento y su [informe de verificación](https://github.com/developer-implementos/pos-platform/blob/23a1cb80c3db4ac010ce7aba93132da3025c3877/delivery/reviews/F02-13-verification.md). La evidencia incluye composición sobre PostgreSQL, concurrencia, respuesta perdida, reinicio, permisos y navegador conectado. La [PR #97](https://github.com/developer-implementos/pos-platform/pull/97) registra la verificación contra ese commit integrado, mantiene la aceptación humana en `null` y alimenta el snapshot publicado desde `98f8987`. La homologación del proveedor permanece separada.

| Acción del operador | Contrato y permiso | Resultado |
| --- | --- | --- |
| Consultar recuperación | `GET /api/v1/payment-intents/:paymentIntentId/recovery`, `payment.read` | Lee plan, versiones, importes y decisiones disponibles sin ejecutar efectos. |
| Completar venta | `POST /api/v1/payment-plans/:planId/finalize`, `sale.confirm` | Reutiliza el plan y los fondos confirmados; confirma venta y outbox en la misma transacción sin realizar otro cobro. |
| Reservar compensación | `POST /api/v1/payment-intents/:paymentIntentId/compensations`, `payment.compensate` | Persiste tipo, importe, motivo y destino original. Todavía no envía la anulación o el reembolso al proveedor. |
| Revisar una reserva | `GET /api/v1/payment-compensations/:compensationId/execution-options`, `payment.read` | Consulta si la reserva sigue pendiente de envío y puede ejecutarse. No despacha dinero. |
| Ejecutar compensación | `POST /api/v1/payment-compensations/:compensationId/execute`, `payment.compensate` | Despacha la reserva tras otra confirmación explícita del operador y una nueva validación del servidor. |
| Solicitar revisión operativa | `POST /api/v1/payment-intents/:paymentIntentId/recovery-review`, `payment.reconcile` | Conserva una solicitud por pago con motivo y evidencia calculada por el servidor; no devuelve dinero ni libera reservas. |

El cliente exige también lectura del pago para operar este panel. Las consultas revalidan la autorización vigente y devuelven motivos cuando una decisión no está disponible. Un operador puede consultar pagos del mismo puesto e instalación, pero el plan comercial de otro operador permanece oculto y sus acciones de ejecución y finalización bloqueadas; el permiso de compensación no elimina la propiedad del plan. La cancelación local de una reserva tiene el alcance específico descrito debajo. Un pago histórico sin plan no adquiere un contexto comercial por inferencia.

El saldo ofrecido para reservar procede del agregado completo en PostgreSQL, descontando compensaciones pendientes o confirmadas; no se calcula con la página visible del historial. Antes de una reserva nueva se comprueban el adaptador exacto del destino original, las capacidades y las restricciones de importe, tipo de tarjeta y lote. La referencia de un lote no demuestra que siga abierto: el adaptador debe verificar la condición del proveedor al ejecutar. Cambiar el perfil vigente no redirige un pago o una reserva anteriores.

**Reservar y ejecutar son dos decisiones distintas.** Cada una requiere revisar la información y confirmar expresamente. Cerrar el diálogo no cancela una reserva durable. Si después falta el adaptador, la reserva permanece hasta una decisión válida; no se marca una devolución manual para desbloquearla. La cancelación local anterior al envío se describe en el incremento siguiente. La finalización y la reserva se serializan mediante el plan: una reserva pendiente impide completar la venta y una venta finalizada rechaza la compensación F02.

**Respuesta perdida:** el cliente conserva el comando completo necesario para recuperarlo, incluido el motivo cuando corresponde, aislado por API, usuario, puesto, instalación y pago. No conserva credenciales ni respuestas del proveedor. El operador recupera explícitamente la misma identidad y payload; recargar o consultar no envía un comando automáticamente ni borra un pendiente. Si la venta ya figura confirmada, todavía puede recuperarse el recibo del comando original. Los errores de lectura bloquean acciones basadas en una consulta anterior y los cambios de sesión o selección invalidan respuestas tardías.

Las pruebas de composición de este incremento unen propietarios reales de identidad, pagos, planes, ventas y outbox sobre PostgreSQL. Incluyen cobro aprobado, fallo después de escribir el outbox y reinicio, pérdida real del acuse de `COMMIT`, carrera entre finalización y reserva y recuperación de la reserva antes de ejecutar. El proveedor externo usado para esas pruebas es un simulador contractual aislado; no se instala en la API operativa ni acredita homologación bancaria.

Si el proveedor no permite compensar o consultar, se mantienen el pago y la evidencia originales sin afirmar que se devolvió dinero. El operador puede registrar una **solicitud de revisión operativa** con motivo. El servidor conserva identidad, pago, plan, solicitante y fecha, junto con el estado, importes, destino original y decisiones disponibles en ese momento. La solicitud es inmutable y única por pago; se puede consultar después de recargar y recuperar con el mismo comando si se pierde la respuesta. El cliente no puede aportar ni sobrescribir esa evidencia.

Registrar la revisión no modifica estados financieros, ni marca dinero devuelto ni cancela una reserva. Tampoco impide completar después una venta que vuelva a cumplir sus condiciones; la solicitud conserva su evidencia histórica y no pasa por ello a presentarse como resuelta. La solicitud de pago no asigna responsables ni tiene un ciclo de cierre propio: [TASK-114](#autoridad-del-seguimiento-de-excepciones) incorpora ese seguimiento en un expediente separado, integrado mediante la PR #118. No implementa asignación automática, SLA ni todas las acciones de recuperación de F02-04.

La migración aditiva `241_payment_recovery_review_requests` conserva esas solicitudes en `payments.payment_recovery_review_request`, con unicidad por pago, protección contra actualización y borrado y permisos runtime de lectura/inserción. Ejecutar el migrador propietario y comprobar la API con manifiesto compatible antes de desplegar el cliente; conservar la ventana controlada indicada arriba. El manifiesto exacto también exige una compilación compatible con la 241 para revertir comportamiento. No se eliminan comandos, solicitudes, reservas ni evidencia para permitir otra operación. La verificación técnica y el porcentaje siguen el registro del producto, sin aceptación humana implícita.

### Cancelación de una reserva antes del envío

[TASK-166](https://github.com/developer-implementos/pos-platform/issues/166), integrado mediante la [PR #172](https://github.com/developer-implementos/pos-platform/pull/172) en [`3929549`](https://github.com/developer-implementos/pos-platform/commit/39295496b2e9488b60ce57f9165205c066f687c4), añade la cancelación local de reservas de compensación anteriores al envío.

Desde **Revisar ejecución**, un usuario con lectura del pago y permiso vigente `payment.compensate` puede confirmar **Cancelar reserva**, con motivo, sólo cuando la compensación sigue en `created` y no tiene intentos asociados. La cancelación local no necesita un adaptador disponible. Un usuario autorizado del mismo puesto e instalación puede retirar esa reserva aunque no sea propietario del plan; esto no le concede ejecución externa ni finalización del plan ajeno. El servidor vuelve a comprobar las condiciones y la versión, también al recuperar una solicitud cuya respuesta se perdió.

**Reserva cancelada antes del envío** significa que se retiró únicamente esa reserva de compensación. El pago aprobado, su identidad, destino e importe, la reserva de ventas, caja, fiscalidad y cuarentenas se conservan. No se llama al proveedor ni se acredita dinero devuelto. La reserva cancelada deja de consumir capacidad de compensación y no impide por sí sola finalizar una venta financiada; las demás condiciones siguen vigentes. Un intento ya registrado impide esta cancelación, aunque su resultado sea incierto.

La decisión conserva motivo, actor y hora en evidencia inmutable; compite con ejecución y finalización mediante la misma exclusión transaccional. La migración `243_compensation_cancellation` exige conservar conjuntamente la transición y su evidencia, y protege el estado terminal frente a nuevos intentos. El [runbook del propietario de pagos](https://github.com/developer-implementos/pos-platform/blob/39295496b2e9488b60ce57f9165205c066f687c4/libs/backend/payments/README.md#cancelación-de-una-reserva-antes-del-envío) mantiene los pasos de confirmación, recuperación de la misma solicitud, revisión del resultado y actualización o reversión compatible del servicio. La acción no resuelve devoluciones de ventas finalizadas ni documentos correctivos de F04.

### Búsqueda y original fiscal protegido

La consulta fiscal combina un intervalo de **fecha de registro UTC**, cliente del snapshot, folio exacto, tipo exacto y estado. `createdFrom` incluye el instante inicial; `createdBefore` excluye el final. El cliente aplica o limpia los filtros explícitamente y reinicia la paginación. La fecha no se presenta como fecha legal de emisión. La búsqueda de cliente usa nombre o identificador del snapshot inmutable, sin consultar maestros ni completar artificialmente documentos históricos que no guardaban esos datos.

El detalle consulta `GET /api/v1/fiscal/documents/:documentId/representation` con permiso `document.read`. Devuelve hash, MIME, tamaño, versión y `available`. Un documento pendiente o rechazado no permite descargar; una referencia sin bytes conservados informa `available: false`. No se fabrica un PDF vacío para suplir el original.

Cuando existe, `GET /api/v1/fiscal/documents/:documentId/representation/content` entrega el **PDF original** tras volver a comprobar el ámbito y el permiso. Los bytes viven en PostgreSQL, en `fiscal.representation_content.content` (`bytea`), con un máximo de **10 MiB** por original. La migración aditiva `234_fiscal_original_content` impide sustituir o borrar el contenido y comprueba que documento aceptado, referencia, MIME, tamaño y SHA-256 coincidan. Los listados no cargan los bytes. Esta solución usa el respaldo de PostgreSQL para el volumen inicial; la retención regulatoria y su capacidad operativa se validan con el perfil de F05.

La incorporación se realiza mediante el adaptador fiscal autorizado, después de persistir evidencia aceptada. La lectura del proveedor ocurre fuera de la transacción, con plazo, cancelación y límite de bytes; luego se guarda el original validado. Un fallo de archivo no revierte la aceptación fiscal ni provoca otra emisión. La recuperación interna `captureRepresentation` puede conservar ese mismo original después de una interrupción, pero no tiene endpoint público ni un planificador automático. Los GET de metadatos y descarga sólo leen PostgreSQL, incluso después de reiniciar la aplicación.

El servidor valida firma y terminador PDF, tamaño y hash sin modificar el original; no se presenta como análisis antimalware. Lo entrega como `attachment`, con nombre derivado del identificador, `no-store`, `nosniff` y CSP `sandbox`, sin exponer rutas o URLs del proveedor. El cliente comprueba MIME, tamaño y hash antes de preparar la descarga. Descargar, copiar, enviar y reimprimir son acciones diferentes: ninguna lectura crea otro documento fiscal y el envío externo sigue deshabilitado.

En navegador, el adaptador de escritorio inicia una descarga mediante un `Blob` local. La URL temporal se libera al terminar su ventana de uso o al destruir la vista; no incluye credenciales ni una dirección del proveedor. Iniciar esa descarga no acredita que el operador haya guardado el archivo. El host Tauri usa el guardado nativo explícito descrito a continuación.

La composición móvil de Capacitor mantiene la exportación **no disponible**. Puede consultar el estado y los metadatos autorizados, pero bloquea la descarga antes del GET de contenido; no descarga bytes para intentar guardarlos por un mecanismo no habilitado. La ausencia de un adaptador también conserva ese bloqueo. Compartir o guardar desde la plataforma móvil exige su adaptador y comprobación propios. **Móvil queda fuera de las aplicaciones de F02-12**, cuya ficha comprende `pos-desktop` y `branch-api`; no se añade como requisito artificial para cerrar ese entregable.

### Guardado nativo en Windows

La [PR #94](https://github.com/developer-implementos/pos-platform/pull/94), integrada en [`d5d5e5f`](https://github.com/developer-implementos/pos-platform/commit/d5d5e5f30fe44f2c2c64fec3e45ba3fe7e3b6d01), compone `save_protected_pdf` en el host Tauri de **POS Desktop para Windows**. El frontend obtiene el original mediante la API autorizada y transmite bytes binarios, un nombre sugerido limitado y SHA-256. Rust vuelve a comprobar la envoltura PDF, el hash y el máximo de **10 MiB** antes de abrir el diálogo. No recibe una ruta elegida por JavaScript ni credenciales de sesión o del proveedor. La prueba de interacción dentro de la aplicación nativa conserva su estado pendiente; los builds y las pruebas automáticas no la sustituyen.

El operador elige el destino mediante el diálogo de Windows. La creación del archivo impide sobrescribir un destino existente, incluso si aparece entre la elección y la escritura. El host devuelve `saved` únicamente después de escribir y sincronizar el contenido; cerrar el diálogo devuelve `cancelled`. Un error se muestra como error, sin anunciar que el PDF quedó guardado. Estas comprobaciones preservan el original y no sustituyen un análisis antimalware.

| Entorno o resultado | Qué puede afirmar la interfaz |
| --- | --- |
| Tauri · `saved` | El host completó la escritura y sincronización del archivo elegido |
| Tauri · `cancelled` | El operador canceló el diálogo; el guardado no se realizó |
| Navegador · `started` | Se inició la descarga; el navegador no confirma al POS que el archivo se guardó |
| Error o capacidad ausente | La entrega no se confirma; no se usa una descarga del navegador como fallback de un fallo nativo |

El permiso se limita a ese comando y a la ventana local `main`. El frontend no recibe una API genérica de archivos, shell o apertura automática. La exclusión en el cliente y el host evita diálogos simultáneos. Después de una respuesta tardía, el store vuelve a comprobar la vista, sesión y permiso antes de actualizar mensajes o datos visibles. Esa comprobación de interfaz **no cancela una escritura nativa ya iniciada**.

El vínculo con la venta original se conserva en la fuente fiscal inmutable. **La relación con correcciones posteriores sigue pendiente**: el flujo de devolución y sus efectos fiscales corresponde a F04. Mostrar que esa capacidad no está disponible no acredita ese vínculo ni completa literalmente el criterio de F02-12. Descargar, enviar, reimprimir y corregir conservan acciones y permisos diferentes.

### Migraciones y acceso a las consultas

Las migraciones aditivas `230_payment_lookup_index`, `231_fiscal_document_lookup` y `232_device_job_lookup` incorporan índices de lectura en sus contextos. No reescriben las migraciones anteriores ni modifican estados financieros, documentos o permisos de ejecución.

`233_operation_read_access` añade `payment.read`, `fiscal.read` y `device.read` al rol protegido `branch-administrator` de sucursales operativas cuando faltan. Incrementa la versión de los roles actualizados y revoca sus sesiones activas: el administrador debe autenticarse nuevamente para obtener los permisos efectivos. Los roles ordinarios conservan sus permisos y sesiones. Esta ampliación de lectura no autoriza comandos de cobro, fiscalidad ni dispositivos.

### Estado y mantenimiento del terminal de pago

**TASK-365 · integrado en `main` mediante la [PR #372](https://github.com/developer-implementos/pos-platform/pull/372), revisión [`d6c0d14`](https://github.com/developer-implementos/pos-platform/commit/d6c0d144aa3ee3fedfe70fc139df056a34679a02).** Es el primer corte de [F02-14](https://github.com/developer-implementos/pos-platform/issues/36). La vista «Terminales de pago» de Seguimiento de operaciones usa estos contratos:

| Acción | Contrato y permiso | Resultado |
| --- | --- | --- |
| Consultar los terminales y su estado | `GET /api/v1/payment-terminals` y `GET /api/v1/payment-terminals/status?terminalRef=`, `terminal.read` | Consulta sin efectos y con tiempo acotado; no crea venta, pago ni cierre de caja |
| Solicitar un mantenimiento | `POST /api/v1/payment-terminals/maintenance-operations`, `terminal.maintain` | Registra la solicitud y toma la exclusión del terminal antes de llamar al adaptador; es idempotente por `commandId` |

El estado distingue `disconnected`, `connected-manual`, `ready` y `unavailable` con motivo, e informa su origen (`adapter` o `server`) y su antigüedad. Sólo un adaptador puede afirmar `ready`: el contrato impide que el servidor lo deduzca, y «conectado» no se presenta como «listo». Sin adaptador compuesto, todo terminal responde `unavailable` con `adapter-unavailable` y no se admite ningún mantenimiento. El inventario de capacidades administrativas por terminal (`payments.terminal_capability_state`) lo escribe sólo el aprovisionamiento del propietario.

El mantenimiento comparte con los cobros la exclusión del terminal. Con un cobro en curso, incierto o en cuarentena, se rechaza con `PAYMENT_RECONCILIATION_REQUIRED` sin descartar el intento previo. Repetir el mismo `commandId` tras una respuesta perdida devuelve la misma operación sin otro efecto. Un resultado desconocido queda `uncertain` en `payments.terminal_operation` y mantiene el terminal excluido de los cobros; todavía no existe un comando para resolverlo.

La migración `246_terminal_maintenance` agrega esas dos tablas y amplía la protección de la exclusión. `247_terminal_maintenance_access` concede `terminal.read` y `terminal.maintain` sólo al administrador protegido y revoca sus sesiones; el administrador puede delegarlos con el mecanismo existente. El incremento no decide qué otro rol los recibe ([Q-57](/project/questions/#q-57)), qué valida «terminal listo» ([Q-29](/project/questions/#q-29)) ni cómo se relacionan el cierre de caja y el lote ([Q-55](/project/questions/#q-55)). El adaptador real del terminal llega por el host y sigue en [FOLLOWUP-002](/project/attention/#followup-002) y [FOLLOWUP-004](/project/attention/#followup-004); este corte no modifica `apps/device-agent`.

### Cierre del lote del terminal

**TASK-376 · integrado en `main` mediante la [PR #380](https://github.com/developer-implementos/pos-platform/pull/380), revisión [`db49e43`](https://github.com/developer-implementos/pos-platform/commit/db49e43f4d002b2492b2d759deee1196f7e5c956).** Es el segundo corte de F02-14.

`POST /api/v1/payment-terminals/batch-closures` (`closePaymentTerminalBatchV1`) exige `terminal.maintain` y es idempotente por `commandId`. Registra el intento en `payments.terminal_batch`, de la migración `252_terminal_batch`, y toma la exclusión del terminal en la misma transacción, antes de llamar al adaptador con tiempo acotado. Un cobro en curso, incierto o en cuarentena lo impide, igual que al mantenimiento. El estado del terminal agrega el último cierre y si se admite otro, y la vista pide confirmación antes de cerrar.

| Resultado | Qué conserva |
| --- | --- |
| `closed` | `batchRef`, fecha de cierre y totales del proveedor por categoría; libera el terminal |
| `failed` | Un fallo concluyente; libera el terminal |
| `uncertain` | Sin respuesta, con `unknown` o con evidencia de otro terminal u otra clave; el terminal queda excluido de cobros, mantenimientos y cierres |

El mismo `commandId` nunca vuelve a llamar al cierre. Si se perdió la respuesta HTTP, repetirlo devuelve el cierre registrado con su `batchRef`; la vista lo ofrece como **Recuperar mismo cierre**. Si se perdió la respuesta del adaptador y este implementa la consulta opcional del lote, la repetición explícita consulta por la clave propia del cierre y registra el resultado concluyente (`resolvedBy: inquiry`). Sin esa consulta, el cierre sigue `uncertain`. Un cierre `requested` cuyo proceso se cayó, y un mantenimiento incierto, siguen excluyendo el terminal: su resolución queda fuera de este corte.

**El cierre del lote no cierra la caja.** No modifica el turno ni crea ventas, pagos o movimientos de caja; los totales son evidencia del proveedor y no reemplazan el libro de caja. En runtime todo cierre responde `PROVIDER_CAPABILITY_UNAVAILABLE`, porque no hay adaptador. El recorrido conectado de consultas cubre la sección con un adaptador controlado de prueba, y la [CI de `main`](https://github.com/developer-implementos/pos-platform/actions/runs/44002489011) lo aprobó.

El incremento no decide si el cierre de caja exige, advierte o ignora el cierre del lote ([Q-55](/project/questions/#q-55)) ni qué rol puede cerrarlo ([Q-57](/project/questions/#q-57)); la conciliación entre los totales y los pagos registrados pertenece a F04. El cierre real y la restricción homologada frente a un cobro siguen en [FOLLOWUP-002](/project/attention/#followup-002) y [FOLLOWUP-004](/project/attention/#followup-004). Cerrar la tarea no verifica F02-14.

## Reimpresión autorizada de un documento

**TASK-581 · integrado en `main` mediante la [PR #588](https://github.com/developer-implementos/pos-platform/pull/588), revisión [`2bcff89`](https://github.com/developer-implementos/pos-platform/commit/2bcff892ce23748c43fe93b825d43070cd50864c).** Es un corte de [F02-10](https://github.com/developer-implementos/pos-platform/issues/32) y aplica la respuesta de [Q-17](/project/questions/#q-17): la reimpresión exige un permiso propio y un motivo.

`POST /api/v1/device-jobs/reprints` (`printExistingDocumentV1`) recibe el documento, la versión de su representación, las copias y el motivo, y es idempotente por `commandId`. Crea un trabajo nuevo en el dispositivo del trabajo original y sólo lee el documento guardado: no cobra, no emite un documento fiscal ni confirma otra venta, y conserva el documento y sus importes. `devices.print_request`, de la migración `581_device_print_request`, registra cada solicitud sin modificarla y vincula la copia con su original del mismo documento y sucursal; la reimpresión de una reimpresión enlaza el primer original.

| Situación | Respuesta |
| --- | --- |
| Operador sin `device.reprint` | 403, con la denegación auditada |
| Motivo ausente o vacío, o representación desconocida | 422 `VALIDATION_ERROR` |
| Más copias que el límite de la representación | 422 `DEVICE_COPY_LIMIT_EXCEEDED`; `sale-receipt.v1` admite una copia por solicitud |
| Documento sin impresión original en la caja | 404 `DEVICE_ORIGINAL_NOT_FOUND` |
| Copia o segundo original pedidos con `createDeviceJobV1` | 409 `DEVICE_REPRINT_REQUIRED` |

`createDeviceJobV1` imprime ahora sólo el original. Las solicitudes de un mismo documento se serializan con un bloqueo transaccional, así que dos impresiones simultáneas admiten un único original. Un original fallido se vuelve a imprimir como reimpresión autorizada y motivada.

En el comprobante de venta, la sección «Reimprimir copia» aparece sólo para quien tiene `device.reprint`. Pide un motivo de 5 a 160 caracteres y muestra el envío, el error y el resultado. Si se pierde la respuesta, reenvía la misma solicitud, que no imprime otra copia. «Seguimiento de operaciones» identifica la «Reimpresión del recibo local no fiscal».

Reglas provisionales, pendientes de Producto en [FOLLOWUP-035](/project/attention/#followup-035): sólo el administrador de sucursal recibe `device.reprint`, al migrar con `581_device_reprint_access`; un documento sin impresión original no se imprime como copia; no hay un tope total de reimpresiones por documento; y el motivo es texto libre, sin catálogo.

**Límites.** Cubre sólo el recibo local no fiscal `sale-receipt.v1`: no hay plantilla DTE ni adaptador homologado, y el host sigue sin driver físico habilitado. Ningún recorrido Playwright cubre la sección. Los demás criterios de F02-10 siguen pendientes: caída después del spooler, falta de papel y caracteres especiales con una capacidad homologada, y plantilla desconocida o payload excesivo en el host. Cerrar la tarea no verifica F02-10.

## Recorrido durable del host

El diagrama describe el recorrido de un adaptador habilitado. El runtime actual detecta que no hay driver, registra un resultado conocido sin efecto y consulta el permiso al entregar esa evidencia; no invoca hardware ni finge recorrer la rama física.

```mermaid
sequenceDiagram
    participant B as branch-api · devices
    participant P as PostgreSQL sucursal
    participant A as device-agent · .NET
    participant S as SQLite del puesto
    participant D as Adaptador de dispositivo
    B->>P: Guardar trabajo autorizado y destino
    A->>B: POST jobs/poll · credencial de instalación
    B-->>A: Sobre v1 + payloadJson + hash
    A->>S: Guardar recepción durable
    A->>B: POST jobs/{jobId}/ack · identidad + hash
    B-->>A: Estado de recepción + hora del servidor
    A->>S: Registrar attemptId antes del permiso
    A->>B: POST jobs/{jobId}/execute · attemptId
    B->>P: Consumir permiso de un uso
    B-->>A: authorized / uncertain / resolved / expired
    alt Permiso nuevo y vigencia disponible
        A->>D: Ejecutar sólo con adaptador habilitado
    else Respuesta perdida o permiso ya consumido
        Note over A,D: No repetir el efecto
    end
    A->>S: Guardar resultado y evidencia
    A->>B: POST jobs/{jobId}/results · resultId estable
    B->>P: Conservar resultado o evidencia tardía
    B-->>A: Acuse de recepción durable
    A->>S: Registrar acuse sin borrar identidad
```

El agente consulta trabajos por HTTPS saliente con espera acotada entre ciclos. No abre un servidor HTTP local ni recibe desde Angular rutas, comandos shell o una dirección de impresora arbitraria. El backend construye el payload del recibo existente y valida el ámbito del operador; el host valida contrato, hash, dispositivo, instalación y época de control. El payload actual resume identificadores e importes de un comprobante local: no es una representación fiscal ni la plantilla completa de impresión de F02-10.

La recepción durable no permite ejecutar indefinidamente. El host vuelve a consultar el acuse al recuperar un trabajo y usa la hora del servidor para calcular el presupuesto restante, descontando el tiempo completo de ida y vuelta con un reloj monotónico. Revalida ese presupuesto después de adquirir la exclusión del dispositivo y antes del efecto.

El permiso de ejecución se consume en PostgreSQL **antes** de responder `authorized`. Sólo esa primera respuesta permite ejecutar. Repetir la petición devuelve incertidumbre o resolución, nunca otro permiso. Así, restaurar una SQLite anterior al intento no autoriza una segunda impresión. Si la respuesta se pierde, el host conserva el resultado conocido o la incertidumbre; no deduce que el permiso quedó libre.

## Contrato v1 y estados

Los esquemas públicos TypeScript están en `libs/backend/devices/contracts`; C# valida el mismo formato mediante fixtures compartidos. Las rutas del host tienen prefijo `/api/v1/device-host/`. El transporte permite sólo el origen HTTPS configurado, sin redirecciones y con validación TLS del sistema. La credencial propia de instalación no se sustituye por la sesión de un operador. La autenticación mutua y la rotación previstas por el contrato objetivo no se atribuyen a este primer transporte.

| Intercambio | Contenido y significado |
| --- | --- |
| Trabajo | `jobId`, sucursal, puesto, instalación controladora, época, dispositivo, capacidad, creación y vencimiento |
| Payload | `payloadJson` y SHA-256 de sus bytes UTF-8 exactos; máximo 16 KiB. Plantilla `sale-receipt.v1`, documento, indicador de copia y hasta 40 líneas de 120 escalares Unicode; no admite caracteres de control |
| Recepción | `received`, `expired` o `resolved`, junto con la hora del servidor. Conserva identidad; no confirma papel ni cobro |
| Permiso | `authorized`, `uncertain`, `resolved` o `expired`, con el intento autoritativo. Una respuesta ambigua no habilita hardware |
| Resultado | `resultId`, `jobId`, `attemptId`, época, hash, estado, motivo, hora observada y evidencia cuando corresponda |

Los UUID se expresan en minúsculas, los hashes en hexadecimal y las fechas UTC con milisegundos. El payload se comprueba sobre sus bytes originales; no se vuelve a serializar para calcular su identidad.

`jobId` identifica el trabajo autorizado; `attemptId`, el intento que puede producir el efecto; `resultId`, una observación durable de ese intento. Reenviar una observación conserva su `resultId`. Cambiar esos identificadores para salir de una espera rompería la recuperación y no está permitido.

| Resultado | Qué acredita |
| --- | --- |
| `failed` | Fallo conocido sin efecto, como driver no disponible, vencimiento o cancelación anterior a la ejecución |
| `uncertain` | No hay evidencia suficiente para resolver el efecto; un reinicio durante el intento conserva este estado |
| `spooled` | El spooler aceptó el trabajo y existe evidencia de esa recepción; no demuestra salida física |
| `succeeded` | El adaptador aporta evidencia del efecto físico exigida por su contrato |

El resultado y su intento permanecen correlacionados. Evidencia tardía más débil del mismo intento se conserva sin hacer retroceder el estado. El acuse del resultado significa recepción durable, no que ese resultado haya reemplazado la evidencia más fuerte. Un intento distinto no puede apropiarse del trabajo. Si el servidor ya resolvió el intento o reconoce otro intento autoritativo, el host conserva su evidencia como superada por la resolución remota, sin fingir un acuse de entrega.

`occurredAt` describe la observación del host; la admisión y las transiciones se deciden con el permiso, el ámbito y el estado durable del servidor. El reloj del puesto no convierte evidencia en autorización ni invalida por sí solo un reporte ya conservado.

### Respuestas de error y compatibilidad del host

**TASK-655 · integrado en `main` mediante la [PR #672](https://github.com/developer-implementos/pos-platform/pull/672), revisión [`8a9b191`](https://github.com/developer-implementos/pos-platform/commit/8a9b191b221da652c67837dd27606fe060662681).** No cambia el contrato `device-protocol`, el esquema ni las respuestas de `branch-api`.

- **Lectura acotada.** El transporte del host lee como máximo 1 MiB de una respuesta correcta y 4 KiB de un cuerpo de error, aunque la respuesta no declare `Content-Length`, y descarta el resto. Del cuerpo de error común sólo conserva `code`.
- **Aplazamiento del acuse.** En `/ack`, `DEVICE_STATE_CONFLICT` corresponde sólo a un trabajo retenido en cola y vigente. El host aplaza su ciclo únicamente ante un 409 con ese código; los demás rechazos siguen siendo fatales.
- **`branch-api` anterior.** Si el poll con declaración de capacidades recibe 422 `VALIDATION_ERROR`, el host registra una vez `DeviceHostDeclarationRejected` y consulta sin declaración hasta reiniciarse. Sólo lo hace si su declaración incluye v1 y `receipt.print`, lo que el servidor actual entiende por una consulta sin declaración, y cada trabajo entregado se sigue validando igual. El orden de despliegue es primero `branch-api` y después el host.
- **Reversión.** Volver `branch-api` a una versión anterior a la migración `563_device_delivery_hold` sin revertir los datos hace fallar la recepción de un trabajo retenido en cola, y el host aplaza su ciclo, hasta que el rol propietario libera esas retenciones según la [guía de devices](https://github.com/developer-implementos/pos-platform/blob/8a9b191b221da652c67837dd27606fe060662681/libs/backend/devices/README.md). Es un límite aceptado y no se automatiza.

Las pruebas .NET (`device:check`), la interoperabilidad (`device:interop`) y la integración de `devices` sobre PostgreSQL cubren estos casos con datos sintéticos; no acreditan un driver ni hardware.

## Host, almacenamiento y entrega

El SDK está fijado a **.NET 10.0.403**, con dependencias y lockfiles versionados. El ejecutable publicado para Windows x64 depende del runtime .NET 10. Nx coordina los comandos; no convierte el host en una aplicación NestJS. La configuración pública y el archivo de credencial permanecen fuera del artefacto, en rutas locales protegidas por la cuenta de servicio.

SQLite usa WAL, sincronización `FULL` y transacciones breves. La identidad de la base está vinculada al origen, sucursal, puesto, instalación, época y dispositivos configurados: cambiar ese ámbito no reasigna silenciosamente una base existente. Una exclusión del proceso protege la instancia; la base impide dos intentos en ejecución para el mismo dispositivo. El código no mantiene una transacción SQL abierta mientras espera red o hardware.

Los comandos reproducibles están en POS Platform: `pnpm run device:restore`, `pnpm run device:check`, `pnpm run device:publish` y `pnpm run device:interop`. La [guía del host](https://github.com/developer-implementos/pos-platform/blob/a98f08e3223abe95f12a4ea4f0de9bcde5c15865/apps/device-agent/README.md) define configuración y límites. Publicar el binario y validar su configuración no acredita instalación SCM, privilegios de servicio, actualización, firma o recuperación de un driver real.

## Evidencia observada y pendientes

La revisión del corte observa pruebas C# sobre SQLite real, caídas abruptas de procesos, duplicados, respuesta perdida, permiso consumido, presupuesto monotónico y restauración de copias antiguas. Los fixtures comunes incluyen trabajo, resultado, recepción y permiso. La prueba TLS negativa rechaza un certificado no confiable antes de transmitir la credencial.

La interoperabilidad ejecuta el host de pruebas contra **Nest/Fastify con HTTPS y PostgreSQL aislado**, usando los mismos transporte, coordinador y journal del producto. Dos trabajos terminan `failed / DRIVER_UNAVAILABLE`; sus recepciones, permisos, intentos y resultados quedan correlacionados. Un segundo proceso sobre la misma SQLite no produce trabajos ni reportes adicionales. Este resultado demuestra el protocolo entre procesos, no impresión física.

Los criterios técnicos de **F02-09** están cubiertos por ese recorrido y las pruebas de contrato, autorización, vigencia y recuperación. La dependencia de perfiles/destinos se satisface mediante su contrato estable; eso no completa la matriz de proveedores de F02-07. La verificación técnica debe conservar su revisión y evidencia, separada de la aceptación humana. La instalación productiva del servicio, el driver y el hardware pertenecen a sus respectivos entregables.

La ampliación fiscal tiene 33 pruebas focales aprobadas, junto con 39 del frontend, 93 de runtime y 23 de la API integrada. Se comprobaron la actualización de la migración 070 a la 234 y los parámetros binarios con offsets, además del contenido exacto descargado, los permisos y los archivos ausentes o alterados. El primer intento HTTP agotó la espera de disponibilidad bajo carga local; la repetición aislada pasó sin relajar las pruebas ni sus tiempos. La matriz técnica conserva estas evidencias por corte; las nuevas regresiones E2E y los checks alojados se consultan en la PR, sin atribuirles resultados de una revisión anterior.

Para cerrar los entregables restantes se necesitan los adaptadores y contratos operativos, entre ellos los de tarjeta y terminal con los que el cobro, el mantenimiento y el cierre de lote ya publicados dejan de responder «no disponible». También se necesitan la matriz de modelos/SDK, la instalación y la cuenta del host, las acciones de recuperación por efecto que la bandeja de excepciones todavía no ofrece, plantillas completas y pruebas de proveedor/hardware. `api-impresion-caja` aporta evidencia de compatibilidad a analizar; sus dependencias .NET Framework, x86 y `System.Drawing.Printing` no se trasladan a un servicio moderno sin validación. El detalle permanece en el [ADR de dispositivos](decisions/device-agent.md) y la [matriz de extensibilidad](extensibilidad-proveedores-dispositivos.md).

El incremento de **F02-05/06** tiene 18 pruebas PostgreSQL de planes/evidencia, 8 de finalización de venta, 4 HTTP integradas y 47 focales del cliente aprobadas. Incluyen la resolución autorizada de transferencias existentes después de deshabilitar nuevas declaraciones. La compatibilidad de la API reúne 141 casos, incluidos los anteriores que pertenecen a esa suite, y la de configuración/dispositivos 11; no se suman ejecuciones solapadas como pruebas diferentes. El recorrido ampliado E2E aprobó **1/1** sobre `dacccc0ee40ab759595494a823ccda7ed43e122f`, con árbol limpio y revisión estable: dos operadores, bytes del PDF, verificación manual, efectivo, recuperación tras recargar, finalización y comprobante. La corrección del exportador aprobó además 5 pruebas focales. Es una prueba de navegador sobre HTTPS y PostgreSQL reales con datos aislados; no acredita guardado nativo en WebView, recepción bancaria ni hardware. Los resultados se atribuyen a sus revisiones comprobadas, sin trasladarlos a una fuente anterior. Los criterios financieros del plan pueden comprobarse con contratos estables y un proveedor exclusivo de pruebas; eso no acredita la tarjeta real de F02-01. Las cuentas compartidas entre sucursales y otros vouchers conservan contratos y validaciones propios. Estos límites no se sustituyen por un bloqueo genérico de Finanzas ni convierten toda la fase en completa.

### Evidencia técnica por revisión

La admisión de proveedores de la [PR #93, revisión `b3aae07`](https://github.com/developer-implementos/pos-platform/pull/93) aprobó typecheck, lint con fronteras Nx, **14 pruebas unitarias y 30 sobre PostgreSQL real aislado**, junto con la [CI del producto](https://github.com/developer-implementos/pos-platform/actions/runs/41480315534) y la [política de PR](https://github.com/developer-implementos/pos-platform/actions/runs/41480315709). El caso concurrente envía doce solicitudes con siete comandos distintos: no crea intenciones ni reservas, conserva siete rechazos y sólo permite una admisión posterior con configuración compatible y un comando nuevo. Otro caso reemplaza el perfil por versiones no registradas y recupera el pago incierto mediante el destino original, sin repetir el cargo. El simulador contractual queda exclusivamente en pruebas; esta evidencia no corresponde a Transbank ni a hardware.

La exportación Windows de la [PR #94, revisión `7f09c63`](https://github.com/developer-implementos/pos-platform/commit/7f09c635ecbdaeb0dd6501e5d05fdf0e0a02aa79) aprobó **14 pruebas Rust con archivos reales en Windows**, Clippy en release con `-D warnings` y la compilación release. La inspección con Node 22.23.3 comprobó formato PE, arquitectura, assets incorporados, CSP e identificador de revisión incorporado. El ejecutable verificado tiene **4.340.736 bytes** y SHA-256 `3f4790b77c2b9e7e9612ec12832e0e5d4a511740afbf9c8a63df92d3d14fe010`; su revisión declarada coincide con `7f09c63`, aunque la inspección por sí sola no certifica el origen del binario. **La prueba de interfaz nativa sigue pendiente**: inspeccionar ese binario no acredita haber utilizado el diálogo real ni guardado desde WebView2. Su resultado se incorpora sólo con la revisión y evidencia correspondientes.

La guía [F01](phase-1-laboratory.md) sigue describiendo la administración operativa y el recorrido comercial existentes. F02 los complementa; no activa automáticamente tarjetas, fiscalidad o periféricos por compilar nuevos módulos.
